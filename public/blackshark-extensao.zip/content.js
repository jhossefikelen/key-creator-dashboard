(function () {
  if (document.getElementById('next-widget-root')) return; // evita duplicar

  // Garante que a Space Grotesk carregue mesmo se o @import do CSS
  // for bloqueado por alguma política da página. Injetar o <link> no
  // <head> é o caminho mais compatível.
  (function ensureFont() {
    const ID = 'lunax-space-grotesk-font';
    if (document.getElementById(ID)) return;
    try {
      const pre = document.createElement('link');
      pre.rel = 'preconnect';
      pre.href = 'https://fonts.gstatic.com';
      pre.crossOrigin = 'anonymous';
      document.head.appendChild(pre);

      const link = document.createElement('link');
      link.id = ID;
      link.rel = 'stylesheet';
      link.href = 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap';
      document.head.appendChild(link);
    } catch (_) { /* se falhar, os fallbacks do CSS assumem */ }
  })();

  const logoUrl = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
    ? chrome.runtime.getURL('logo.png')
    : 'logo.png';

  const config = window.LUNAX_CONFIG || window.VERTEX_CONFIG || {};
  const supportUrl = config.SUPPORT_URL || 'https://wa.me/55119947664626?text=Ol%C3%A1!%20Preciso%20de%20ajuda%20com%20a%20minha%20chave%20do%20Black%20Shark';

  const root = document.createElement('div');
  root.id = 'next-widget-root';
  root.innerHTML = `
    <!-- BOTÃO FLUTUANTE (BOLINHA) -->
    <button id="nextLauncher" title="Abrir Black Shark">
      <img class="next-launcher-img" src="${logoUrl}" alt="Black Shark" />
      <div class="next-launcher-fallback" style="display:none;">L</div>
    </button>

    <!-- MODAL DE ATIVAÇÃO DE LICENÇA (IDÊNTICO À IMAGEM) -->
    <div class="lunax-modal-backdrop" id="lunaxLicenseModal" style="display:none;">
      <div class="lunax-license-card">
        <button class="lunax-modal-close" id="lunaxLicenseCloseBtn" title="Fechar">
          <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>

        <div class="lunax-license-logo-wrap">
          <img class="lunax-license-logo" src="${logoUrl}" alt="Black Shark" />
        </div>

        <div class="lunax-license-brand">
          <span class="lunax-brand-name">Black Shark</span>
        </div>

        <p class="lunax-license-subtitle">Insira sua chave para ativar a extensão.</p>

        <form class="lunax-license-form" id="lunaxLicenseForm">
          <label class="lunax-license-label" for="lunaxLicenseInput">CHAVE DE LICENÇA</label>
          <div class="lunax-input-box">
            <input 
              type="text" 
              id="lunaxLicenseInput" 
              class="lunax-license-input" 
              placeholder="Sua chave de licença..." 
              autocomplete="off"
              spellcheck="false"
              required
            />
          </div>

          <div class="lunax-license-msg" id="lunaxLicenseMsg" style="display:none;"></div>

          <button type="submit" class="lunax-license-btn" id="lunaxActivateBtn">
            <span class="btn-text">Ativar Licença</span>
            <span class="btn-spinner" style="display:none;"></span>
          </button>
        </form>

        <div class="lunax-license-footer">
          <a href="${supportUrl}" target="_blank" rel="noopener noreferrer" class="lunax-support-link">
            Precisa de ajuda? Fale com o suporte ›
          </a>
        </div>
      </div>
    </div>

    <!-- PAINEL PRINCIPAL BLACK SHARK -->
    <div class="next-app" id="nextApp" style="display:none;">
      <!-- TOPBAR -->
      <header class="next-topbar" id="nextDragHandle">
        <div class="next-brand">
          <img class="next-brand-logo-img" src="${logoUrl}" alt="Black Shark" />
          <div class="next-brand-text">
            <span class="next-brand-name">Black Shark</span>
          </div>
        </div>
        <div class="next-topbar-actions">
          <button class="next-icon-btn" title="Fechar" data-action="close">
            <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
      </header>

      <!-- USER CARD EXPANSÍVEL (FULANO PRO -> DASHBOARD NEXUS) -->
      <div class="next-user-card" id="nextUserCard">
        <div class="next-user-header">
          <div class="next-user-info">
            <span class="next-user-name" id="nextUserName">—</span>
            <span class="next-pro-badge" id="nextUserBadge">MONTH</span>
          </div>
          <div class="next-user-actions">
            <button class="next-icon-btn small next-exit-btn" id="nextExitBtn" title="Sair / Desconectar">
              <svg viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
            </button>
          </div>
        </div>

        <!-- CORPO EXPANDIDO (IDÊNTICO À IMAGEM) -->
        <div class="next-user-expanded-body" id="nextUserExpandedBody" style="display:flex;">
          <!-- PROGRESS / TEMPO RESTANTE -->
          <div class="next-time-box">
            <div class="next-time-header">
              <span class="next-time-label">
                <svg class="next-icon-inline" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                Tempo restante
              </span>
              <span class="next-time-value" id="nextRemainingDays">30d 1h 16m</span>
            </div>
            <div class="next-progress-track">
              <div class="next-progress-fill" id="nextProgressFill" style="width: 0%;"></div>
            </div>
            <div class="next-time-footer">
              <span id="nextExpiresFooter">Expira em 25/09/2026</span>
            </div>
          </div>

          <!-- STATS ROW -->
          <div class="next-stats-grid">
            <div class="next-stat-box">
              <div class="next-stat-label">
                <svg class="next-icon-inline" viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                COMANDOS
              </div>
              <div class="next-stat-value primary" id="nextCommandsCount">0</div>
            </div>
            <div class="next-stat-box">
              <div class="next-stat-label">
                <svg class="next-icon-inline" viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                ECONOMIA
              </div>
              <div class="next-stat-value success" id="nextSavingsAmount">R$ 0,00</div>
            </div>
          </div>
        </div>
      </div>

      <!-- WORKSPACE LATERAL -->
      <nav class="lunax-side-tabs" aria-label="Áreas da Black Shark">
        <button type="button" class="lunax-side-tab active" data-lunax-tab="assistant">⌂ Início</button>
        <button type="button" class="lunax-side-tab" data-lunax-tab="github">◉ Editor IA</button>
        <button type="button" class="lunax-side-tab" data-lunax-tab="account">♙ Conta</button>
      </nav>

      <section class="lunax-side-view active" data-lunax-view="assistant">
        <div class="lunax-workspace-heading">
          <div>
            <span class="lunax-eyebrow">Black Shark Agent</span>
            <strong>Escolha como começar</strong>
          </div>
          <span class="lunax-online-dot">IA online</span>
        </div>
        <p class="lunax-quick-hint">Use uma ação rápida ou abra o editor para descrever a alteração. Todos os pedidos são enviados pelo mesmo editor integrado ao GitHub.</p>
        <div class="lunax-quick-actions">
          <button type="button" class="lunax-quick-secondary" id="lunaxQuickSelect">⌖ Selecionar elemento</button>
          <button type="button" class="lunax-quick-primary" id="lunaxQuickSend">Abrir editor IA →</button>
        </div>
        <p class="lunax-quick-hint">A alteração será enviada para o GitHub e sincronizada com o Lovable.</p>
        <div class="lunax-section-label">Ações rápidas</div>
        <div class="next-grid" id="nextCommandGrid">
          <button class="next-cmd" data-cmd="Corrigir"><span class="next-cmd-icon">🛠️</span><span class="next-cmd-label">Corrigir</span></button>
          <button class="next-cmd" data-cmd="Refatorar"><span class="next-cmd-icon">⚖️</span><span class="next-cmd-label">Refatorar</span></button>
          <button class="next-cmd" data-cmd="Melhorar"><span class="next-cmd-icon">🎨</span><span class="next-cmd-label">Melhorar</span></button>
          <button class="next-cmd" data-cmd="Explicar"><span class="next-cmd-icon">🔍</span><span class="next-cmd-label">Explicar</span></button>
          <button class="next-cmd" data-cmd="Otimizar"><span class="next-cmd-icon">🚀</span><span class="next-cmd-label">Otimizar</span></button>
          <button class="next-cmd" data-cmd="Segurança"><span class="next-cmd-icon">🛡️</span><span class="next-cmd-label">Segurança</span></button>
          <button class="next-cmd" data-cmd="Copy & Paste"><span class="next-cmd-icon">📋</span><span class="next-cmd-label">Textos</span></button>
          <button class="next-cmd" data-cmd="Responsivo"><span class="next-cmd-icon">📱</span><span class="next-cmd-label">Responsivo</span></button>
          <button class="next-cmd" data-cmd="Cards"><span class="next-cmd-icon">💎</span><span class="next-cmd-label">Cards</span></button>
          <button class="next-cmd" data-cmd="Fix Erros"><span class="next-cmd-icon">🎯</span><span class="next-cmd-label">Fix erros</span></button>
          <button class="next-cmd" data-cmd="Migração"><span class="next-cmd-icon">💾</span><span class="next-cmd-label">Migração</span></button>
          <button class="next-cmd" data-cmd="Transições"><span class="next-cmd-icon">💫</span><span class="next-cmd-label">Transições</span></button>
        </div>
      </section>

      <section class="lunax-side-view" data-lunax-view="github">
        <div class="lunax-workspace-heading">
          <div>
            <span class="lunax-eyebrow">Projeto conectado</span>
            <strong>Editor IA com GitHub</strong>
          </div>
        </div>
        <div class="lunax-github-host" id="lunaxGithubHost"></div>
      </section>

      <section class="lunax-side-view" data-lunax-view="account">
        <div class="lunax-workspace-heading">
          <div>
            <span class="lunax-eyebrow">Sua assinatura</span>
            <strong>Conta Black Shark</strong>
          </div>
        </div>
        <div class="lunax-account-host" id="lunaxAccountHost"></div>
      </section>
      <!-- BOTTOM TOOLBAR -->
      <div class="next-bottom-toolbar">
        <button class="next-icon-btn small" id="nextDockGithub" title="Abrir GitHub"><svg viewBox="0 0 24 24"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/></svg></button>
        <button class="next-icon-btn small" id="nextDockTarget" title="Selecionar elemento"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg></button>
        <button class="next-icon-btn small" id="nextDockShield" title="Bloquear o chat da Lovable"><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg></button>
        <button class="next-icon-btn small" id="nextDockHelp" title="Ajuda e suporte"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></button>
      </div>

      <!-- GitHub incorporado ao painel lateral -->    <div class="lunax-gh-bar" id="lunaxGhBar" style="display:none;">

      <!-- Estado 1: sem conta GitHub conectada -->
      <div class="lunax-gh-state" id="lunaxGhStateDisconnected" style="display:none;">
        <div class="lunax-gh-head">
          <svg class="lunax-gh-icon" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2C6.48 2 2 6.58 2 12.25c0 4.53 2.87 8.37 6.84 9.73.5.1.68-.22.68-.48 0-.24-.01-1.04-.01-1.89-2.78.61-3.37-1.21-3.37-1.21-.46-1.18-1.11-1.5-1.11-1.5-.91-.63.07-.62.07-.62 1 .07 1.53 1.05 1.53 1.05.89 1.55 2.34 1.1 2.91.84.09-.66.35-1.1.63-1.36-2.22-.26-4.56-1.14-4.56-5.06 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.31.1-2.72 0 0 .84-.28 2.75 1.05a9.29 9.29 0 0 1 5 0c1.91-1.33 2.75-1.05 2.75-1.05.55 1.41.2 2.46.1 2.72.64.72 1.03 1.63 1.03 2.75 0 3.93-2.34 4.8-4.57 5.05.36.32.68.94.68 1.9 0 1.37-.01 2.47-.01 2.81 0 .27.18.59.69.48A10.02 10.02 0 0 0 22 12.25C22 6.58 17.52 2 12 2Z"/></svg>
          <span class="lunax-gh-head-text">Conecte o GitHub para editar via IA</span>
          <button class="lunax-gh-x" data-gh-close title="Fechar">×</button>
        </div>
        <button class="lunax-gh-primary-btn" id="lunaxGhConnectBtn">
          <span class="btn-text">Conectar GitHub</span>
          <span class="btn-spinner" style="display:none;"></span>
        </button>
      </div>

      <!-- Estado 2: conectado, escolhendo repositório -->
      <div class="lunax-gh-state" id="lunaxGhStateRepos" style="display:none;">
        <div class="lunax-gh-head">
          <span class="lunax-gh-head-text">Conectado como <b id="lunaxGhLogin"></b></span>
          <button class="lunax-gh-switch" id="lunaxGhSwitchBtn">Trocar conta</button>
          <button class="lunax-gh-x" data-gh-close title="Fechar">×</button>
        </div>
        <div class="lunax-gh-auto-hint" id="lunaxGhAutoHint" style="display:none;"></div>
        <input type="text" id="lunaxGhRepoFilter" class="lunax-gh-filter" placeholder="Filtrar repositórios..." autocomplete="off" />
        <div class="lunax-gh-repo-list" id="lunaxGhRepoList"></div>
        <div class="lunax-gh-branch-box" id="lunaxGhBranchBox" style="display:none;">
          <label class="lunax-gh-branch-label" for="lunaxGhBranchSelect">Branch ativa no Lovable</label>
          <select id="lunaxGhBranchSelect" class="lunax-gh-filter"></select>
          <button class="lunax-gh-primary-btn" id="lunaxGhConfirmRepoBtn">
            <span class="btn-text">Usar repositório e branch</span>
            <span class="btn-spinner" style="display:none;"></span>
          </button>
          <small class="lunax-gh-auto-hint">Escolha a mesma branch exibida no topo do projeto Lovable.</small>
        </div>
      </div>

      <!-- Estado 3: pronto para enviar comandos -->
      <div class="lunax-gh-state" id="lunaxGhStateReady" style="display:none;">
        <div class="lunax-gh-head">
          <svg class="lunax-gh-icon small" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2C6.48 2 2 6.58 2 12.25c0 4.53 2.87 8.37 6.84 9.73.5.1.68-.22.68-.48 0-.24-.01-1.04-.01-1.89-2.78.61-3.37-1.21-3.37-1.21-.46-1.18-1.11-1.5-1.11-1.5-.91-.63.07-.62.07-.62 1 .07 1.53 1.05 1.53 1.05.89 1.55 2.34 1.1 2.91.84.09-.66.35-1.1.63-1.36-2.22-.26-4.56-1.14-4.56-5.06 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.31.1-2.72 0 0 .84-.28 2.75 1.05a9.29 9.29 0 0 1 5 0c1.91-1.33 2.75-1.05 2.75-1.05.55 1.41.2 2.46.1 2.72.64.72 1.03 1.63 1.03 2.75 0 3.93-2.34 4.8-4.57 5.05.36.32.68.94.68 1.9 0 1.37-.01 2.47-.01 2.81 0 .27.18.59.69.48A10.02 10.02 0 0 0 22 12.25C22 6.58 17.52 2 12 2Z"/></svg>
          <span class="lunax-gh-repo-name" id="lunaxGhRepoName"></span>
          <button class="lunax-gh-switch" id="lunaxGhChangeRepoBtn">Trocar</button>
          <button class="lunax-gh-x" data-gh-close title="Fechar">×</button>
        </div>
        <div class="lunax-sel-chip" id="lunaxSelChip" style="display:none;"></div>
        <textarea id="lunaxGhPrompt" class="lunax-gh-textarea" rows="2" placeholder="Descreva a alteração que você quer..."></textarea>
        <div class="lunax-gh-actions">
          <button class="lunax-gh-pick" id="lunaxGhAttachBtn" title="Anexar imagem de referência ou arquivo">
            <svg viewBox="0 0 24 24"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
          </button>
          <input type="file" id="lunaxGhFileInput" multiple style="display:none;"
                 accept="image/png,image/jpeg,image/webp,image/gif,.txt,.md,.json,.csv,.html,.css,.js,.ts,.jsx,.tsx" />
          <button class="lunax-gh-pick" id="lunaxGhPickBtn" title="Selecionar elemento no Preview">
            <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/><circle cx="12" cy="12" r="8"/></svg>
          </button>
          <button class="lunax-gh-send" id="lunaxGhSendBtn" title="Enviar pra IA">
            <svg class="send-icon" viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
            <span class="send-spinner" style="display:none;"></span>
          </button>
        </div>
        <div class="lunax-gh-attach-list" id="lunaxGhAttachList" style="display:none;"></div>
        <div class="lunax-gh-msg" id="lunaxGhMsg" style="display:none;"></div>
        <div class="lunax-gh-result" id="lunaxGhResult" style="display:none;"></div>
      </div>
    </div>
    <!-- ══════════════════════════════════════════════════════════
         BARRA DO BANCO DE DADOS (Supabase do cliente)
         Fluxo em duas etapas: gera o SQL → cliente revisa → aplica.
         Nada roda no banco sem passar pela revisão.
         ══════════════════════════════════════════════════════════ -->
    <div class="lunax-gh-bar" id="lunaxDbBar" style="display:none;">

      <div class="lunax-gh-state" id="lunaxDbDisconnected" style="display:none;">
        <div class="lunax-gh-head">
          <span class="lunax-gh-head-text">Conecte seu Supabase para criar e editar tabelas</span>
          <button class="lunax-gh-x" data-db-close title="Fechar">×</button>
        </div>
        <button class="lunax-gh-primary-btn" id="lunaxDbConnectBtn">
          <span class="btn-text">Conectar Supabase</span>
        </button>
      </div>

      <div class="lunax-gh-state" id="lunaxDbProjects" style="display:none;">
        <div class="lunax-gh-head">
          <span class="lunax-gh-head-text">Escolha o projeto</span>
          <button class="lunax-gh-switch" id="lunaxDbSwitchBtn">Trocar conta</button>
          <button class="lunax-gh-x" data-db-close title="Fechar">×</button>
        </div>
        <div class="lunax-gh-repo-list" id="lunaxDbProjectList"></div>
      </div>

      <div class="lunax-gh-state" id="lunaxDbReady" style="display:none;">
        <div class="lunax-gh-head">
          <span class="lunax-gh-repo-name" id="lunaxDbProjectName"></span>
          <button class="lunax-gh-switch" id="lunaxDbChangeProjectBtn">Trocar</button>
          <button class="lunax-gh-x" data-db-close title="Fechar">×</button>
        </div>
        <textarea id="lunaxDbPrompt" class="lunax-gh-textarea" rows="2"
          placeholder="Ex: crie uma tabela de depósitos com valor, status e data"></textarea>
        <div class="lunax-gh-actions">
          <button class="lunax-gh-send" id="lunaxDbGenBtn" title="Gerar SQL">
            <svg class="send-icon" viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
            <span class="send-spinner" style="display:none;"></span>
          </button>
        </div>

        <!-- Revisão: o SQL aparece aqui ANTES de rodar -->
        <div class="lunax-db-preview" id="lunaxDbPreview" style="display:none;">
          <div class="lunax-db-explain" id="lunaxDbExplain"></div>
          <pre class="lunax-db-sql" id="lunaxDbSql"></pre>
          <div class="lunax-db-warn" id="lunaxDbWarn" style="display:none;"></div>
          <div class="lunax-db-buttons">
            <button class="lunax-db-cancel" id="lunaxDbCancelBtn">Cancelar</button>
            <button class="lunax-db-apply" id="lunaxDbApplyBtn">Aplicar no banco</button>
          </div>
        </div>
      </div>

      <!-- Mensagem e resultado ficam FORA dos estados: assim o erro
           aparece mesmo na tela de conectar (antes ficavam dentro do
           estado "pronto" e o cliente não via nada acontecer). -->
      <div class="lunax-gh-msg" id="lunaxDbMsg" style="display:none;"></div>
      <div class="lunax-gh-result" id="lunaxDbResult" style="display:none;"></div>
    </div>
  `;
  
  let isMounted = false;
  function mountRoot() {
    if (document.getElementById('next-widget-root')) return;
    try {
      (document.body || document.documentElement).appendChild(root);
      isMounted = true;
    } catch (e) {}
  }

  mountRoot();
  
  // Garante que o widget não seja destruído por frameworks (React/Next.js/Lovable)
  const observer = new MutationObserver(() => {
    if (isMounted && !document.contains(root)) {
      mountRoot();
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mountRoot);
  }

  // ============================================================================
  // FLUXO LIMPO: UI + LICENÇA APENAS
  // ============================================================================
  const launcher = root.querySelector('#nextLauncher');
  const app = root.querySelector('#nextApp');
  const grid = root.querySelector('#nextCommandGrid');
  const quickPrompt = root.querySelector('#lunaxQuickPrompt');
  const quickSend = root.querySelector('#lunaxQuickSend');
  const quickSelect = root.querySelector('#lunaxQuickSelect');
  const sideTabs = Array.from(root.querySelectorAll('[data-lunax-tab]'));
  const sideViews = Array.from(root.querySelectorAll('[data-lunax-view]'));
  const githubHost = root.querySelector('#lunaxGithubHost');
  const accountHost = root.querySelector('#lunaxAccountHost');
  const githubBarElement = root.querySelector('#lunaxGhBar');
  const userCardElement = root.querySelector('#nextUserCard');

  if (githubHost && githubBarElement) githubHost.appendChild(githubBarElement);
  if (accountHost && userCardElement) accountHost.appendChild(userCardElement);

  function setSideTab(name) {
    const next = ['assistant', 'github', 'account'].includes(name)
      ? name
      : 'assistant';
    sideTabs.forEach((button) => {
      button.classList.toggle('active', button.dataset.lunaxTab === next);
    });
    sideViews.forEach((view) => {
      view.classList.toggle('active', view.dataset.lunaxView === next);
    });
    chrome.storage.local.set({ lunax_side_tab: next }).catch(() => {});
  }

  sideTabs.forEach((button) => {
    button.addEventListener('click', () => setSideTab(button.dataset.lunaxTab));
  });
  chrome.storage.local.get(['lunax_side_tab']).then((saved) => {
    setSideTab(saved.lunax_side_tab || 'assistant');
  }).catch(() => setSideTab('assistant'));
  const githubToolbarButton = root.querySelector('#nextDockGithub');
  const targetToolbarButton = root.querySelector('#nextDockTarget');
  const helpToolbarButton = root.querySelector('#nextDockHelp');
  const licenseModal = root.querySelector('#lunaxLicenseModal');
  const licenseForm = root.querySelector('#lunaxLicenseForm');
  const licenseInput = root.querySelector('#lunaxLicenseInput');
  const licenseMsg = root.querySelector('#lunaxLicenseMsg');
  const activateBtn = root.querySelector('#lunaxActivateBtn');
  const licenseCloseBtn = root.querySelector('#lunaxLicenseCloseBtn');
  const userCard = root.querySelector('#nextUserCard');
  const userExpandedBody = root.querySelector('#nextUserExpandedBody');
  const userBadge = root.querySelector('#nextUserBadge');
  const userName = root.querySelector('#nextUserName');
  const exitBtn = root.querySelector('#nextExitBtn');
  const remainingDaysEl = root.querySelector('#nextRemainingDays');
  const progressFillEl = root.querySelector('#nextProgressFill');
  const expiresFooterEl = root.querySelector('#nextExpiresFooter');
  const commandsCountEl = root.querySelector('#nextCommandsCount');
  const savingsAmountEl = root.querySelector('#nextSavingsAmount');

  // ============================================================================
  // FLUXO DE LICENÇA — produção
  // ============================================================================
  let isLicensed = false;
  let activeProfile = null;
  const commandQueue = [];
  let isQueuePaused = false;

  app.style.top = '0';
  app.style.right = '0';

  // ── Barra "Tempo restante": cor por fase ──────────────────────────
  //   roxo     → mais da metade do período
  //   amarelo  → passou da metade
  //   vermelho → falta menos de 1 hora (pulsa)
  //   cinza    → expirado
  const TIME_COLOR_FULL    = '#7c3aed';
  const TIME_COLOR_HALF    = '#eab308';
  const TIME_COLOR_LOW     = '#ef4444';
  const TIME_COLOR_EXPIRED = '#e2e8f0';

  function computeRemaining(expiresAtIso, activatedAtIso) {
    if (!expiresAtIso) {
      return { text: 'Sem expiração', pct: 100, color: TIME_COLOR_FULL, low: false, expired: false };
    }
    const now = Date.now();
    const expiresAtMs = new Date(expiresAtIso).getTime();
    if (Number.isNaN(expiresAtMs)) {
      return { text: '—', pct: 0, color: TIME_COLOR_EXPIRED, low: false, expired: false };
    }
    const diff = expiresAtMs - now;
    if (diff <= 0) {
      return { text: 'Expirado', pct: 0, color: TIME_COLOR_EXPIRED, low: false, expired: true };
    }

    const days  = Math.floor(diff / 86400000);
    const hours = Math.floor((diff % 86400000) / 3600000);
    const mins  = Math.floor((diff % 3600000) / 60000);
    const text  = `${days}d ${hours}h ${mins}m`;

    // Percentual baseado no período total (ativação → expiração)
    const startMs = activatedAtIso ? new Date(activatedAtIso).getTime() : null;
    let pct = 100;
    if (startMs && expiresAtMs > startMs) {
      pct = Math.max(0, Math.min(100, (diff / (expiresAtMs - startMs)) * 100));
    }

    const low = diff <= 3600000;
    let color = TIME_COLOR_FULL;
    if (low) color = TIME_COLOR_LOW;
    else if (startMs && pct <= 50) color = TIME_COLOR_HALF;

    return { text, pct, color, low, expired: false };
  }

  // Atualiza a barra a cada minuto para o tempo correr em tempo real
  let timeTicker = null;
  function refreshTimeBar() {
    if (!activeProfile) return;
    const r = computeRemaining(activeProfile.expiresAtIso, activeProfile.activatedAtIso);
    remainingDaysEl.textContent = r.text;
    if (progressFillEl) {
      progressFillEl.style.width = `${r.pct}%`;
      progressFillEl.style.background = r.color;
      progressFillEl.classList.toggle('is-low', r.low);
    }
    remainingDaysEl.style.color = r.expired ? '#94a3b8' : r.color;
  }
  function startTimeTicker() {
    if (timeTicker) clearInterval(timeTicker);
    refreshTimeBar();
    timeTicker = setInterval(refreshTimeBar, 60000);
  }

  function profileFromPayload(data, key) {
    const expiresRaw   = data.expires_at || data.expiresAt || null;
    const activatedRaw = data.activated_at || data.activatedAt || new Date().toISOString();
    let expiresAt = 'Sem expiração';
    if (expiresRaw) {
      const exp = new Date(expiresRaw);
      if (!Number.isNaN(exp.getTime())) expiresAt = exp.toLocaleDateString('pt-BR');
    }
    const r = computeRemaining(expiresRaw, activatedRaw);
    // Nome do cliente: account_name da licença > prefixo do email >
    // "Licença XXXXX" (últimos 5 da chave) como último recurso.
    // Melhor mostrar algo identificável que um "Usuário" genérico.
    const nameFromKey = key ? `Licença ${String(key).slice(-5).toUpperCase()}` : 'Cliente';
    const userName = data.customerName || data.customer_name
      || data.user_name || data.userName || data.account_name
      || (data.email ? String(data.email).split('@')[0] : null)
      || nameFromKey;

    return {
      licenseKey: key,
      userName,
      plan: data.plan || 'PRO',
      expiresAt,
      expiresAtIso: expiresRaw,
      activatedAtIso: activatedRaw,
      remainingDays: r.text,
      commandsCount: String(data.commands_count ?? data.commandsCount ?? '0'),
      savingsAmount: String(data.savings_amount ?? data.savingsAmount ?? 'R$ 0,00'),
      offlineUntil: data.offlineUntil || data.offline_until || null
    };
  }

  function applyProfileData(profile) {
    activeProfile = profile;
    if (!profile) return;
    userName.textContent = profile.userName || 'Cliente';
    userName.title = profile.userName || '';
    expiresFooterEl.textContent = profile.expiresAt === 'Sem expiração'
      ? 'Sem expiração'
      : `Expira em ${profile.expiresAt}`;
    commandsCountEl.textContent = profile.commandsCount || '0';
    savingsAmountEl.textContent = profile.savingsAmount || 'R$ 0,00';
    userBadge.textContent = String(profile.plan || 'PRO').toUpperCase();
    startTimeTicker();
  }

  // ── Device ID ──────────────────────────────────────────────────────
  // A licença é vinculada a um dispositivo. Geramos um UUID uma única vez
  // e guardamos no storage local — o mesmo device sempre reusa o dele.
  let cachedDeviceId = null;
  async function getDeviceId() {
    if (cachedDeviceId) return cachedDeviceId;
    try {
      const saved = await chrome.storage.local.get(['lunax_device_id', 'vertex_device_id']);
      if (saved.lunax_device_id || saved.vertex_device_id) {
        cachedDeviceId = saved.lunax_device_id || saved.vertex_device_id;
        return cachedDeviceId;
      }
    } catch (_) {}
    const id = (crypto?.randomUUID?.() || `dev-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    cachedDeviceId = id;
    try { await chrome.storage.local.set({ lunax_device_id: id }); } catch (_) {}
    return id;
  }

  async function validateLicense(key) {
    const cfg = window.LUNAX_CONFIG || window.VERTEX_CONFIG || {};
    if (!cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY) {
      return { success: false, error: 'Configure SUPABASE_URL e SUPABASE_ANON_KEY no config.js.' };
    }
    const fn = cfg.LICENSE_EDGE_FUNCTION || 'license-validate';
    const deviceId = await getDeviceId();
    const savedSession = await chrome.storage.local.get(['lunax_license_session']);
    try {
      const res = await fetch(`${cfg.SUPABASE_URL}/functions/v1/${fn}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': cfg.SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${cfg.SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({
          action: 'activate',
          licenseKey: key.trim(),
          deviceId,
          sessionToken: savedSession.lunax_license_session || null
        })
      });
      let body = {};
      try { body = await res.json(); } catch (_) {}
      if (!res.ok || !body.ok || !body.profile?.active || !body.sessionToken) {
        return { success: false, error: body.error || `Falha ao validar licença (${res.status}).` };
      }
      await chrome.storage.local.set({
        lunax_license_session: body.sessionToken
      });
      return {
        success: true,
        sessionToken: body.sessionToken,
        data: profileFromPayload(body.profile, key.trim())
      };
    } catch (err) {
      return { success: false, error: 'Não foi possível conectar ao servidor de licenças.' };
    }
  }

  function openPanelFlow() {
    if (isLicensed) {
      app.style.display = app.style.display === 'none' ? 'flex' : 'none';
      licenseModal.style.display = 'none';
    } else {
      app.style.display = 'none';
      licenseModal.style.display = 'flex';
      setTimeout(() => licenseInput.focus(), 0);
    }
  }

  // ── Launcher arrastável ────────────────────────────────────────────
  // Funciona com mouse e toque. Distingue arraste de clique: só abre o
  // painel se o dedo/mouse praticamente não se moveu.
  let lDragging = false, lMoved = false, lStartX = 0, lStartY = 0, lOffX = 0, lOffY = 0;
  const DRAG_THRESHOLD = 5; // px

  function clampLauncher(x, y) {
    const w = launcher.offsetWidth || 52;
    const h = launcher.offsetHeight || 52;
    // Margem inferior maior no celular: a Lovable tem uma barra fixa
    // no rodapé (Chat / mic / Publish) e o botão não pode cair em cima dela.
    const bottomGuard = window.innerWidth <= 820 ? 84 : 12;
    return {
      x: Math.max(4, Math.min(window.innerWidth - w - 4, x)),
      y: Math.max(4, Math.min(window.innerHeight - h - bottomGuard, y)),
    };
  }

  function setLauncherPos(x, y) {
    const p = clampLauncher(x, y);
    launcher.style.setProperty('left', p.x + 'px', 'important');
    launcher.style.setProperty('top', p.y + 'px', 'important');
    launcher.style.setProperty('right', 'auto', 'important');
    launcher.style.setProperty('bottom', 'auto', 'important');
    return p;
  }

  function onLauncherDown(e) {
    const pt = e.touches ? e.touches[0] : e;
    const rect = launcher.getBoundingClientRect();
    lDragging = true;
    lMoved = false;
    lStartX = pt.clientX;
    lStartY = pt.clientY;
    lOffX = pt.clientX - rect.left;
    lOffY = pt.clientY - rect.top;
    launcher.style.setProperty('transition', 'none', 'important');
  }

  function onLauncherMove(e) {
    if (!lDragging) return;
    const pt = e.touches ? e.touches[0] : e;
    if (!lMoved) {
      const dist = Math.hypot(pt.clientX - lStartX, pt.clientY - lStartY);
      if (dist < DRAG_THRESHOLD) return; // ainda pode ser um clique
      lMoved = true;
    }
    e.preventDefault();
    setLauncherPos(pt.clientX - lOffX, pt.clientY - lOffY);
  }

  async function onLauncherUp() {
    if (!lDragging) return;
    lDragging = false;
    launcher.style.removeProperty('transition');
    if (lMoved) {
      // salva a posição pra manter entre sessões
      const r = launcher.getBoundingClientRect();
      try { await chrome.storage.local.set({ lunax_launcher_pos: { x: r.left, y: r.top } }); } catch (_) {}
      // impede que o clique dispare depois do arraste
      setTimeout(() => { lMoved = false; }, 0);
    }
  }

  launcher.addEventListener('mousedown', onLauncherDown);
  launcher.addEventListener('touchstart', onLauncherDown, { passive: true });
  document.addEventListener('mousemove', onLauncherMove);
  document.addEventListener('touchmove', onLauncherMove, { passive: false });
  document.addEventListener('mouseup', onLauncherUp);
  document.addEventListener('touchend', onLauncherUp);

  // Restaura a posição salva e mantém dentro da tela ao redimensionar
  chrome.storage.local.get(['lunax_launcher_pos', 'vertex_launcher_pos']).then((saved) => {
    const p = saved.lunax_launcher_pos || saved.vertex_launcher_pos;
    if (p && typeof p.x === 'number') setLauncherPos(p.x, p.y);
  }).catch(() => {});
  window.addEventListener('resize', () => {
    if (launcher.style.left) {
      const r = launcher.getBoundingClientRect();
      setLauncherPos(r.left, r.top);
    }
  });

  launcher.addEventListener('click', (e) => {
    if (lMoved) { e.preventDefault(); e.stopPropagation(); return; } // foi arraste, não clique
    openPanelFlow();
  });
  if (chrome?.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((message) => {
      if (message?.type === 'toggle-panel') openPanelFlow();
    });
  }

  licenseForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const key = licenseInput.value.trim();
    if (!key) return;
    activateBtn.disabled = true;
    activateBtn.querySelector('.btn-text').textContent = 'Validando...';
    activateBtn.querySelector('.btn-spinner').style.display = 'inline-block';
    licenseMsg.style.display = 'none';

    const result = await validateLicense(key);

    activateBtn.disabled = false;
    activateBtn.querySelector('.btn-text').textContent = 'Ativar Licença';
    activateBtn.querySelector('.btn-spinner').style.display = 'none';

    if (!result.success) {
      licenseMsg.textContent = result.error || 'Chave inválida.';
      licenseMsg.className = 'lunax-license-msg error';
      licenseMsg.style.display = 'block';
      return;
    }

    isLicensed = true;
    applyProfileData(result.data);
    await chrome.storage.local.set({ lunax_license_key: key, lunax_profile: result.data });
    licenseMsg.textContent = '✓ Licença ativada com sucesso!';
    licenseMsg.className = 'lunax-license-msg success';
    licenseMsg.style.display = 'block';
    setTimeout(() => {
      licenseModal.style.display = 'none';
      licenseMsg.style.display = 'none';
      app.style.display = 'flex';
    }, 350);
  });

  licenseCloseBtn.addEventListener('click', () => {
    licenseModal.style.display = 'none';
    licenseMsg.style.display = 'none';
  });

  chrome.storage.local.get([
    'lunax_license_key',
    'lunax_profile',
    'lunax_license_session',
    'vertex_license_key',
    'vertex_profile'
  ]).then(async (saved) => {
    const key = saved.lunax_license_key || saved.vertex_license_key;
    const profile = saved.lunax_profile || saved.vertex_profile;
    if (key && profile) {
      isLicensed = true;
      applyProfileData(profile);
      const refreshed = await validateLicense(key);
      if (refreshed.success) {
        isLicensed = true;
        applyProfileData(refreshed.data);
        await chrome.storage.local.set({
          lunax_profile: refreshed.data,
          lunax_license_session: refreshed.sessionToken
        });
      } else if (!profile.offlineUntil || Date.parse(profile.offlineUntil) <= Date.now()) {
        isLicensed = false;
        activeProfile = null;
        await chrome.storage.local.remove([
          'lunax_license_session',
          'lunax_profile',
          'vertex_profile'
        ]);
      }
    }
  }).catch(() => {}).finally(() => {
    openPanelFlow();
  });

  exitBtn?.addEventListener('click', async (e) => {
    e.stopPropagation();
    isLicensed = false;
    activeProfile = null;
    await chrome.storage.local.remove([
      'lunax_license_key',
      'lunax_profile',
      'lunax_license_session',
      'vertex_license_key',
      'vertex_profile'
    ]);
    app.style.display = 'none';
    licenseInput.value = '';
    licenseModal.style.display = 'flex';
    licenseInput.focus();
  });

  grid.addEventListener('click', (e) => {
    const btn = e.target.closest('.next-cmd');
    if (!btn) return;
    grid.querySelectorAll('.next-cmd').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const actionPrompts = {
      'Corrigir': 'Analise o projeto, encontre os erros reais e corrija preservando o que já funciona.',
      'Refatorar': 'Refatore o código da área selecionada para melhorar organização, manutenção e qualidade sem alterar o comportamento.',
      'Melhorar': 'Melhore o design e a experiência da área selecionada, mantendo a identidade atual do projeto.',
      'Explicar': 'Analise a área selecionada e explique de forma objetiva como ela funciona e o que pode ser melhorado.',
      'Otimizar': 'Otimize desempenho, carregamento e qualidade do código sem remover funcionalidades.',
      'Segurança': 'Faça uma auditoria de segurança nesta área e corrija os riscos encontrados sem expor segredos.',
      'Copy & Paste': 'Melhore os textos, títulos, mensagens e chamadas para ação da página mantendo a proposta do projeto.',
      'Responsivo': 'Corrija e melhore a responsividade para celular, tablet e desktop.',
      'Cards': 'Redesenhe os cards desta área para ficarem modernos, organizados e consistentes.',
      'Fix Erros': 'Execute uma análise completa, corrija erros de código, build, lint, imports e funcionalidades quebradas.',
      'Migração': 'Planeje e implemente a migration necessária de forma segura e compatível com o projeto.',
      'Transições': 'Adicione transições e microinterações profissionais, leves e acessíveis.'
    };
    const prompt = actionPrompts[btn.dataset.cmd] || `Aplique a ação: ${btn.dataset.cmd}.`;
    ghPrompt.value = prompt;
    if (quickPrompt) quickPrompt.value = prompt;
    setSideTab('github');
    ghOpen().catch((error) =>
      ghShowMsg(error?.message || 'Falha ao abrir GitHub.', true)
    );
  });

  targetToolbarButton?.addEventListener('click', async () => {
    try {
      await ghOpen();
      startSelection();
    } catch (error) {
      ghShowMsg(error?.message || 'Falha ao iniciar seleção.', true);
    }
  });

  githubToolbarButton?.addEventListener('click', () => {
    setSideTab('github');
    ghOpen().catch((error) =>
      ghShowMsg(error?.message || 'Falha ao abrir GitHub.', true)
    );
  });

  quickSelect?.addEventListener('click', async () => {
    try {
      setSideTab('github');
      await ghOpen();
      startSelection();
    } catch (error) {
      ghShowMsg(error?.message || 'Falha ao iniciar seleção.', true);
    }
  });

  quickSend?.addEventListener('click', async () => {
    quickSend.disabled = true;
    const originalLabel = quickSend.textContent;
    quickSend.textContent = 'Abrindo...';
    try {
      setSideTab('github');
      await ghOpen();
      ghPrompt?.focus();
    } catch (error) {
      ghShowMsg(error?.message || 'Não foi possível abrir o editor.', true);
    } finally {
      quickSend.disabled = false;
      quickSend.textContent = originalLabel || 'Abrir editor IA →';
    }
  });

  helpToolbarButton?.addEventListener('click', () => {
    window.open(supportUrl, '_blank', 'noopener,noreferrer');
  });

  root.querySelector('[data-action="close"]')?.addEventListener('click', () => {
    app.style.display = 'none';
    licenseModal.style.display = 'flex';
  });

  // ══════════════════════════════════════════════════════════════════
  // FLUXO GITHUB
  // Reutiliza as mesmas edge functions já em produção:
  //   github-oauth  → conectar/desconectar conta
  //   github-repos  → listar e selecionar repositório
  //   github-ai-edit → gerar alteração + commit
  // ══════════════════════════════════════════════════════════════════
  const ghBar          = root.querySelector('#lunaxGhBar');
  const ghStateDisc    = root.querySelector('#lunaxGhStateDisconnected');
  const ghStateRepos   = root.querySelector('#lunaxGhStateRepos');
  const ghStateReady   = root.querySelector('#lunaxGhStateReady');
  const ghConnectBtn   = root.querySelector('#lunaxGhConnectBtn');
  const ghLoginEl      = root.querySelector('#lunaxGhLogin');
  const ghRepoFilter   = root.querySelector('#lunaxGhRepoFilter');
  const ghRepoList     = root.querySelector('#lunaxGhRepoList');
  const ghBranchBox    = root.querySelector('#lunaxGhBranchBox');
  const ghBranchSelect = root.querySelector('#lunaxGhBranchSelect');
  const ghConfirmRepoBtn = root.querySelector('#lunaxGhConfirmRepoBtn');
  const ghRepoName     = root.querySelector('#lunaxGhRepoName');
  const ghPrompt       = root.querySelector('#lunaxGhPrompt');
  const ghSendBtn      = root.querySelector('#lunaxGhSendBtn');
  const ghMsg          = root.querySelector('#lunaxGhMsg');
  const ghResult       = root.querySelector('#lunaxGhResult');
  const ghSwitchBtn    = root.querySelector('#lunaxGhSwitchBtn');
  const ghChangeRepoBtn= root.querySelector('#lunaxGhChangeRepoBtn');
  const ghAutoHint     = root.querySelector('#lunaxGhAutoHint');

  let ghAllRepos = [];
  let ghActiveRepo = null;
  let ghPendingRepo = null;
  let ghAgentPollTimer = null;

  async function ghAiCall(auth, payload) {
    const res = await fetch(cfgUrl('GITHUB_AI_EDIT_FUNCTION', 'github-ai-edit'), {
      method: 'POST',
      headers: cfgHeaders(auth.sessionToken, auth.deviceId),
      body: JSON.stringify({ lovableProjectId: auth.lovableProjectId, ...payload })
    });
    const data = await res.json().catch(() => ({}));
    return { res, data };
  }

  function ghRenderAgentJob(auth, job) {
    if (!job || !ghResult) return;
    ghAgentProgressUpdate(job);
    ghResult.style.display = 'block';
    ghResult.textContent = '';
    const title = document.createElement('div');
    const statusIcon = job.status === 'completed' ? '✅' :
      job.status === 'failed' ? '❌' : job.status === 'merging' ? '🛡️' : '⏳';
    title.textContent = `${statusIcon} ${ghAgentStep?.textContent || 'Tarefa Black Shark'}`;
    ghResult.appendChild(title);

    if (job.commitUrl) {
      const commit = document.createElement('a');
      commit.href = job.commitUrl;
      commit.target = '_blank';
      commit.rel = 'noopener noreferrer';
      commit.textContent = 'Abrir commit de validação';
      ghResult.append(document.createElement('br'), commit);
    }
    if (job.pullRequest?.url) {
      const pr = document.createElement('a');
      pr.href = job.pullRequest.url;
      pr.target = '_blank';
      pr.rel = 'noopener noreferrer';
      pr.textContent = `Abrir Pull Request #${job.pullRequest.number}`;
      ghResult.append(document.createElement('br'), pr);
    }
    if (job.previewUrl) {
      const preview = document.createElement('button');
      preview.type = 'button';
      preview.className = 'lunax-agent-preview';
      preview.textContent = 'Visualizar alteração';
      preview.addEventListener('click', () => {
        window.open(job.previewUrl, '_blank', 'noopener,noreferrer');
      });
      ghResult.append(document.createElement('br'), preview);
    }
    if (job.error) {
      const error = document.createElement('small');
      error.className = 'lunax-agent-error';
      error.textContent = ` ${job.error}`;
      ghResult.append(document.createElement('br'), error);
    }
    if (job.status === 'merging') {
      const actions = document.createElement('div');
      actions.className = 'lunax-agent-result-actions';
      const approve = document.createElement('button');
      approve.type = 'button';
      approve.className = 'lunax-agent-approve';
      approve.textContent = 'Publicar no Lovable';
      const cancel = document.createElement('button');
      cancel.type = 'button';
      cancel.className = 'lunax-agent-cancel';
      cancel.textContent = 'Cancelar';
      approve.addEventListener('click', async () => {
        approve.disabled = true;
        ghShowMsg('Publicando a alteração aprovada...');
        const { data } = await ghAiCall(auth, { action: 'agent_publish', jobId: job.id });
        if (!data.ok) {
          ghShowMsg(data.error || 'Falha ao publicar a tarefa.', true);
          approve.disabled = false;
          return;
        }
        ghShowMsg('');
        ghRenderAgentJob(auth, data.job);
      });
      cancel.addEventListener('click', async () => {
        cancel.disabled = true;
        const { data } = await ghAiCall(auth, { action: 'agent_cancel', jobId: job.id });
        if (!data.ok) ghShowMsg(data.error || 'Falha ao cancelar.', true);
        else {
          ghShowMsg('Tarefa cancelada. A branch principal não foi alterada.');
          ghResult.style.display = 'none';
          ghAgentProgress.style.display = 'none';
        }
      });
      actions.append(approve, cancel);
      ghResult.appendChild(actions);
    }
    if (job.status === 'completed') {
      const note = document.createElement('small');
      note.textContent = ' Alteração publicada. O Lovable sincronizará a branch principal.';
      ghResult.append(document.createElement('br'), note);
      const revert = document.createElement('button');
      revert.type = 'button';
      revert.className = 'lunax-agent-revert';
      revert.textContent = 'Desfazer alteração';
      revert.addEventListener('click', async () => {
        if (!window.confirm('Desfazer esta alteração? Isso só funciona se não houver commits posteriores.')) return;
        revert.disabled = true;
        const { data } = await ghAiCall(auth, { action: 'agent_revert', jobId: job.id });
        if (!data.ok) {
          ghShowMsg(data.error || 'Não foi possível desfazer.', true);
          revert.disabled = false;
          return;
        }
        ghShowMsg('Alteração desfeita com segurança.');
        ghRenderAgentJob(auth, data.job);
      });
      ghResult.append(document.createElement('br'), revert);
    }
    if (job.status === 'failed') {
      const retry = document.createElement('button');
      retry.type = 'button';
      retry.className = 'lunax-agent-approve';
      retry.textContent = 'Corrigir e tentar novamente';
      retry.addEventListener('click', async () => {
        retry.disabled = true;
        retry.textContent = 'Corrigindo...';
        ghShowMsg('Lendo o erro real do GitHub e preparando uma nova validação...');
        try {
          const { data } = await ghAiCall(auth, { action: 'agent_retry', jobId: job.id });
          if (!data.ok || !data.job) {
            ghShowMsg(data.error || 'Não foi possível refazer a tarefa.', true);
            retry.disabled = false;
            retry.textContent = 'Corrigir e tentar novamente';
            return;
          }
          ghShowMsg('Nova tentativa iniciada. A branch principal continua protegida.');
          ghRenderAgentJob(auth, data.job);
          ghPollAgentJob(auth, data.job.id);
        } catch (error) {
          ghShowMsg(error?.message || 'Não foi possível refazer a tarefa.', true);
          retry.disabled = false;
          retry.textContent = 'Corrigir e tentar novamente';
        }
      });
      ghResult.append(document.createElement('br'), retry);
    }
  }

  function ghPollAgentJob(auth, jobId) {
    if (ghAgentPollTimer) clearTimeout(ghAgentPollTimer);
    const poll = async () => {
      const { data } = await ghAiCall(auth, { action: 'agent_status', jobId });
      if (!data.ok || !data.job) {
        ghShowMsg(data.error || 'Falha ao acompanhar a tarefa.', true);
        return;
      }
      ghRenderAgentJob(auth, data.job);
      if (['waiting_ci', 'analyzing', 'planning', 'editing', 'validating', 'publishing', 'repairing'].includes(data.job.status)) {
        ghAgentPollTimer = setTimeout(poll, 5000);
      }
    };
    poll();
  }

  function cfgUrl(fnKey, fallback) {
    const cfg = window.LUNAX_CONFIG || window.VERTEX_CONFIG || {};
    return `${cfg.SUPABASE_URL}/functions/v1/${cfg[fnKey] || fallback}`;
  }
  function cfgHeaders(sessionToken, deviceId) {
    const cfg = window.LUNAX_CONFIG || window.VERTEX_CONFIG || {};
    const headers = {
      'Content-Type': 'application/json',
      'apikey': cfg.SUPABASE_ANON_KEY,
      'Authorization': `Bearer ${cfg.SUPABASE_ANON_KEY}`
    };
    if (sessionToken) headers['x-lunax-session'] = sessionToken;
    if (deviceId) headers['x-lunax-device'] = deviceId;
    return headers;
  }

  async function aiRequest(url, options) {
    let lastError = null;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        const response = await fetch(url, options);
        const transient = [408, 425, 429, 500, 502, 503, 504, 520, 521, 522, 523, 524, 525, 526, 529, 530]
          .includes(response.status);
        if (transient && attempt < 2) {
          await new Promise((resolve) => setTimeout(resolve, 700 * (attempt + 1)));
          continue;
        }
        const data = await response.json().catch(() => ({}));
        return { response, data };
      } catch (error) {
        lastError = error;
        if (attempt < 2) {
          await new Promise((resolve) => setTimeout(resolve, 700 * (attempt + 1)));
          continue;
        }
      }
    }
    throw lastError || new Error('A conexão com a IA falhou após novas tentativas.');
  }
  async function ghAuth() {
    const saved = await chrome.storage.local.get(['lunax_license_session']);
    const deviceId = await getDeviceId();
    const sessionToken = saved.lunax_license_session || null;
    if (!sessionToken) throw new Error('Sessão de licença ausente. Ative sua chave novamente.');
    return {
      deviceId,
      sessionToken,
      lovableProjectId: currentLovableProjectId()
    };
  }

  function currentLovableProjectId() {
    const projectUrl = window.BLACK_SHARK_PAGE?.url || location.href;
    const match = projectUrl.match(/\/projects\/([0-9a-f-]{36})(?:\/|$|\?)/i);
    if (!match) throw new Error('Abra um projeto válido no Lovable.');
    return match[1];
  }

  function ghShowMsg(text, isError) {
    if (!ghMsg) return;
    if (!text) { ghMsg.style.display = 'none'; ghMsg.textContent = ''; return; }
    ghMsg.textContent = text;
    ghMsg.className = isError ? 'lunax-gh-msg error' : 'lunax-gh-msg';
    ghMsg.style.display = 'block';
  }

  function ghShowState(name) {
    ghBar.style.display = 'flex';
    setSideTab('github');
    ghStateDisc.style.display  = name === 'disconnected' ? 'flex' : 'none';
    ghStateRepos.style.display = name === 'repos'        ? 'flex' : 'none';
    ghStateReady.style.display = name === 'ready'        ? 'flex' : 'none';
  }

  function ghCloseBar() {
    setSideTab('assistant');
    ghShowMsg('');
  }
  root.querySelectorAll('[data-gh-close]').forEach(b => b.addEventListener('click', ghCloseBar));

  // ── Detecção automática do repositório ────────────────────────────
  // Não existe um mapeamento oficial entre o UUID do projeto Lovable e o
  // nome do repositório no GitHub. O que dá pra fazer com segurança é
  // pegar o NOME do projeto que a Lovable mostra na tela e casar com o
  // nome do repositório. Quando bate com confiança, seleciona sozinho.
  // ── Detecção do repositório ───────────────────────────────────────
  // Estratégia em duas camadas:
  //  1) LER da própria Lovable — o projeto já é vinculado ao GitHub lá,
  //     então o nome "dono/repo" aparece no DOM (link do GitHub, menu de
  //     configurações, etc). É a fonte confiável.
  //  2) Só se não achar nada, cai no palpite por similaridade de nome.

  // Aceita "dono/repo" com as regras reais de nome do GitHub
  const REPO_RE = /\b([A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?)\/([A-Za-z0-9._-]{1,100})\b/;

  // Coisas que parecem "a/b" mas não são repositório
  const NOT_REPO = new Set([
    'lovable.dev','lovable.app','github.com','www.github.com',
    'application/json','text/html','image/png','image/jpeg',
  ]);

  function looksLikeRepo(owner, name) {
    const full = `${owner}/${name}`.toLowerCase();
    if (NOT_REPO.has(full)) return false;
    if (owner.length < 1 || name.length < 1) return false;
    if (/^\d+$/.test(owner) && /^\d+$/.test(name)) return false; // "1/2"
    if (name.endsWith('.js') || name.endsWith('.css') || name.endsWith('.png')) return false;
    return true;
  }

  // Procura o repositório vinculado, lendo o que a Lovable já mostra
  function detectRepoFromLovable() {
    const connectedRepo = window.BLACK_SHARK_PAGE?.repo;
    if (connectedRepo) return { full: connectedRepo, source: 'projeto Lovable' };

    // (a) Qualquer link direto pro GitHub — jeito mais confiável
    const links = Array.from(document.querySelectorAll('a[href*="github.com/"]'));
    for (const a of links) {
      const href = a.getAttribute('href') || '';
      const m = href.match(/github\.com\/([A-Za-z0-9][A-Za-z0-9-]*)\/([A-Za-z0-9._-]+)/);
      if (m && looksLikeRepo(m[1], m[2])) {
        return { full: `${m[1]}/${m[2].replace(/\.git$/, '')}`, source: 'link do GitHub' };
      }
    }

    // (b) Texto visível no formato dono/repo, em elementos pequenos
    //     (badge, item de menu, cabeçalho) — evita varrer a página toda
    const candidates = Array.from(document.querySelectorAll(
      '[class*="github" i], [data-testid*="github" i], [aria-label*="github" i], ' +
      '[class*="repo" i], [data-testid*="repo" i], header *, [role="menu"] *'
    ));
    for (const el of candidates) {
      if (el.closest('#next-widget-root')) continue;  // ignora a nossa UI
      const txt = (el.textContent || '').trim();
      if (!txt || txt.length > 80) continue;          // blocos grandes: pula
      const m = txt.match(REPO_RE);
      if (m && looksLikeRepo(m[1], m[2])) {
        return { full: `${m[1]}/${m[2]}`, source: 'interface da Lovable' };
      }
    }

    // (c) Atributos que costumam guardar a URL/nome do repositório
    //     mesmo quando ele não está escrito na tela
    const attrEls = Array.from(document.querySelectorAll(
      '[title],[aria-label],[data-repo],[data-repository],[data-github-repo]'
    ));
    for (const el of attrEls) {
      if (el.closest('#next-widget-root')) continue;
      for (const attr of ['data-repo', 'data-repository', 'data-github-repo', 'title', 'aria-label']) {
        const v = el.getAttribute(attr);
        if (!v) continue;
        const m2 = v.match(/github\.com\/([A-Za-z0-9][A-Za-z0-9-]*)\/([A-Za-z0-9._-]+)/);
        if (m2 && looksLikeRepo(m2[1], m2[2])) {
          return { full: `${m2[1]}/${m2[2].replace(/\.git$/, '')}`, source: `atributo ${attr}` };
        }
        // formato "dono/repo" puro, só em atributos dedicados a repo
        if (attr.startsWith('data-')) {
          const d = v.trim().match(/^([A-Za-z0-9][A-Za-z0-9-]*)\/([A-Za-z0-9._-]+)$/);
          if (d && looksLikeRepo(d[1], d[2])) {
            return { full: `${d[1]}/${d[2]}`, source: `atributo ${attr}` };
          }
        }
      }
    }

    // (d) Storage da própria Lovable — o vínculo com o GitHub costuma
    //     ficar guardado aqui mesmo quando não aparece na tela
    try {
      for (const store of [localStorage, sessionStorage]) {
        for (let i = 0; i < store.length; i++) {
          const k = store.key(i);
          if (!k) continue;
          const v = store.getItem(k) || '';
          if (v.length > 200000) continue;             // pula blobs enormes
          if (!v.toLowerCase().includes('github')) continue;
          const m3 = v.match(/github\.com\/([A-Za-z0-9][A-Za-z0-9-]*)\/([A-Za-z0-9._-]+)/);
          if (m3 && looksLikeRepo(m3[1], m3[2])) {
            return { full: `${m3[1]}/${m3[2].replace(/\.git$/, '')}`, source: 'dados da Lovable' };
          }
        }
      }
    } catch (_) { /* storage pode estar bloqueado */ }

    return null;
  }

  function getLovableProjectName() {
    const connectedTitle = String(window.BLACK_SHARK_PAGE?.title || '').trim();
    if (connectedTitle && connectedTitle.toLowerCase() !== 'lovable') return connectedTitle;
    const fromTitle = (document.title || '').replace(/\s*[-–|]\s*Lovable.*$/i, '').trim();
    if (fromTitle && fromTitle.toLowerCase() !== 'lovable') return fromTitle;
    const sels = ['[data-testid="project-name"]', '.project-name', 'header h1', 'header [class*="title"]'];
    for (const s of sels) {
      const el = document.querySelector(s);
      const t = el?.textContent?.trim();
      if (t && t.length > 1 && t.length < 80) return t;
    }
    return null;
  }

  // ── Detecção do repositório vinculado no próprio Lovable ──────────
  // O Lovable guarda o repositório conectado em
  //   /projects/{id}/settings/git/github
  // Como essa página é do MESMO domínio (lovable.dev), a extensão pode
  // lê-la sem esbarrar em cross-origin. É bem mais confiável que tentar
  // adivinhar pelo nome do projeto.

  function getLovableProjectId() {
    const projectUrl = window.BLACK_SHARK_PAGE?.url || location.href;
    const m = projectUrl.match(/\/projects\/([0-9a-f-]{36})/i);
    return m ? m[1] : null;
  }

  // Procura no HTML/DOM qualquer referência a github.com/dono/repo
  function extractRepoFromText(text) {
    if (!text) return null;
    // github.com/owner/repo — ignora caminhos internos do GitHub
    const re = /github\.com\/([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)/g;
    const ignore = new Set(['orgs','settings','apps','features','about','pricing','login','signup','marketplace','topics','collections','sponsors','site']);
    let m;
    while ((m = re.exec(text)) !== null) {
      const owner = m[1];
      let repo = m[2].replace(/\.git$/, '').replace(/["'<>)\]},;]+$/, '');
      if (ignore.has(owner.toLowerCase())) continue;
      if (!repo || repo.length < 1) continue;
      return `${owner}/${repo}`;
    }
    return null;
  }

  // 2) Abre a página de settings do Git num iframe oculto (mesma origem)
  //    e lê o repositório de lá depois que o React renderizar.
  function findRepoViaSettingsPage(projectId, timeoutMs = 9000) {
    return new Promise((resolve) => {
      const url = `${location.origin}/projects/${projectId}/settings/git/github`;
      const frame = document.createElement('iframe');
      frame.setAttribute('aria-hidden', 'true');
      frame.style.cssText = 'position:fixed;width:900px;height:700px;left:-10000px;top:0;opacity:0;pointer-events:none;border:0;';
      let done = false;

      const finish = (val) => {
        if (done) return;
        done = true;
        clearInterval(poll);
        clearTimeout(killer);
        try { frame.remove(); } catch (_) {}
        resolve(val);
      };

      // O conteúdo é renderizado pelo React, então não basta o onload:
      // ficamos verificando o DOM do iframe até achar o repositório.
      const poll = setInterval(() => {
        try {
          const doc = frame.contentDocument;
          if (!doc || !doc.body) return;
          const link = doc.querySelector('a[href*="github.com/"]');
          if (link) {
            const r = extractRepoFromText(link.getAttribute('href'));
            if (r) return finish(r);
          }
          const r2 = extractRepoFromText(doc.body.innerText || '');
          if (r2) return finish(r2);
        } catch (_) {
          // se por algum motivo virar cross-origin, desiste em silêncio
          finish(null);
        }
      }, 400);

      const killer = setTimeout(() => finish(null), timeoutMs);
      frame.src = url;
      document.body.appendChild(frame);
    });
  }

  // Orquestra: página atual → settings → (fallback) nome do projeto
  function normalizeName(s) {
    return String(s || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // tira acentos
      .replace(/[^a-z0-9]+/g, '');                       // só letras+números
  }

  // Retorna o repositório que casa com o projeto aberto, ou null se
  // não houver um candidato claro. Nunca "chuta": se dois repos
  // empatarem, devolve null e deixa o usuário escolher.
  function findMatchingRepo(repos, projectName) {
    if (!projectName || !repos?.length) return null;
    const target = normalizeName(projectName);
    if (target.length < 3) return null;

    // Também compara "por palavras": o nome do projeto costuma ter
    // palavras que aparecem no repo mesmo sem casar a string inteira
    // (ex: "Portal Comunicação" → "portal-comm").
    const targetWords = String(projectName).toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .split(/[^a-z0-9]+/).filter(w => w.length >= 3);

    const scored = repos.map(r => {
      const repoShort = normalizeName((r.full_name || '').split('/').pop());
      const repoWords = String((r.full_name || '').split('/').pop()).toLowerCase()
        .split(/[^a-z0-9]+/).filter(w => w.length >= 3);

      let score = 0;
      if (repoShort === target) score = 100;
      else if (repoShort.startsWith(target)) score = 80;
      else if (target.startsWith(repoShort)) score = 75;
      else if (repoShort.includes(target)) score = 60;
      else if (target.includes(repoShort)) score = 58;

      // Bônus por palavras em comum (cada palavra que bate por prefixo)
      if (targetWords.length && repoWords.length) {
        let hits = 0;
        for (const tw of targetWords) {
          if (repoWords.some(rw => rw.startsWith(tw) || tw.startsWith(rw))) hits++;
        }
        if (hits > 0) {
          const ratio = hits / Math.max(targetWords.length, repoWords.length);
          score = Math.max(score, Math.round(ratio * 90));
        }
      }
      return { repo: r, score };
    }).filter(x => x.score > 0).sort((a, b) => b.score - a.score);

    if (!scored.length) return null;
    if (scored[0].score < 55) return null;

    // Margem de segurança: se o 2º colocado está perto do 1º, é ambíguo
    // demais pra decidir sozinho — devolve null e o usuário escolhe.
    // (ex: "app-vendas" vs "app-vendas-v2" — nunca chutar entre os dois)
    if (scored.length > 1) {
      const gap = scored[0].score - scored[1].score;
      const isExactWinner = scored[0].score === 100 && scored[1].score < 100;
      if (!isExactWinner && gap < 20) return null;
    }
    return scored[0].repo;
  }

  function ghRenderRepos(filter) {
    const q = (filter || '').toLowerCase();
    const list = ghAllRepos.filter(r => !q || r.full_name.toLowerCase().includes(q));
    ghRepoList.textContent = '';
    if (!list.length) {
      const empty = document.createElement('div');
      empty.className = 'lunax-gh-empty';
      empty.textContent = 'Nenhum repositório encontrado.';
      ghRepoList.appendChild(empty);
      return;
    }
    const fragment = document.createDocumentFragment();
    list.forEach((repo) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'lunax-gh-repo-item';
      button.dataset.repo = repo.full_name;
      const name = document.createElement('span');
      name.className = 'repo-name';
      name.textContent = repo.full_name;
      button.appendChild(name);
      if (repo.private) {
        const badge = document.createElement('span');
        badge.className = 'repo-badge';
        badge.textContent = 'PRIVADO';
        button.appendChild(badge);
      }
      fragment.appendChild(button);
    });
    ghRepoList.appendChild(fragment);
  }

  async function ghCallRepos(payload) {
    const auth = await ghAuth();
    const res = await fetch(cfgUrl('GITHUB_REPOS_FUNCTION', 'github-repos'), {
      method: 'POST',
      headers: cfgHeaders(auth.sessionToken, auth.deviceId),
      body: JSON.stringify({
        lovableProjectId: auth.lovableProjectId,
        ...payload
      })
    });
    const data = await res.json().catch(() => ({}));
    return { res, data };
  }

  async function ghSelectRepo(fullName, isAuto) {
    ghShowMsg(isAuto ? 'Detectando repositório do projeto...' : 'Carregando branches...');
    const { data } = await ghCallRepos({ action: 'branches', repoFullName: fullName });
    if (!data.ok) {
      ghShowMsg(data.error || 'Falha ao carregar branches.', true);
      return false;
    }
    ghPendingRepo = fullName;
    ghBranchSelect.textContent = '';
    const branches = [...(data.branches || [])].sort((a, b) => {
      if (a.name === data.defaultBranch) return -1;
      if (b.name === data.defaultBranch) return 1;
      return a.name.localeCompare(b.name);
    });
    branches.forEach(branch => {
      const option = document.createElement('option');
      option.value = branch.name;
      option.textContent = `${branch.name}${branch.protected ? ' (protegida)' : ''}`;
      ghBranchSelect.appendChild(option);
    });
    ghBranchBox.style.display = 'flex';
    ghShowMsg('Confirme a mesma branch que está ativa no Lovable.');
    return true;
  }

  // Abre o fluxo: decide sozinho qual estado mostrar
  async function ghOpen() {
    if (!isLicensed) { openPanelFlow(); return; }
    ghShowState('repos');
    ghRepoList.innerHTML = '<div class="lunax-gh-empty">Carregando...</div>';
    ghAutoHint.style.display = 'none';
    ghBranchBox.style.display = 'none';

    let data = {};
    try {
      ({ data } = await ghCallRepos({ action: 'list' }));
    } catch (error) {
      ghShowState('repos');
      ghRepoList.textContent = '';
      const empty = document.createElement('div');
      empty.className = 'lunax-gh-empty';
      empty.textContent = error?.message || 'Falha ao carregar o GitHub.';
      ghRepoList.appendChild(empty);
      return;
    }

    if (!data.ok) {
      if (data.code === 'NOT_CONNECTED') { ghShowState('disconnected'); return; }
      ghShowState('repos');
      ghRepoList.textContent = '';
      const empty = document.createElement('div');
      empty.className = 'lunax-gh-empty';
      empty.textContent = data.error || 'Falha ao carregar.';
      ghRepoList.appendChild(empty);
      return;
    }

    ghAllRepos = data.repos || [];
    ghLoginEl.textContent = '@' + (data.login || '');

    // Já havia um repo salvo? vai direto pro estado pronto.
    if (data.selectedRepo && data.selectedBranch) {
      ghActiveRepo = data.selectedRepo;
      ghRepoName.textContent = `${data.selectedRepo} · ${data.selectedBranch}`;
      ghShowState('ready');
      return;
    }

    // ── Detecção do repositório, em ordem de confiança ──────────────
    // 1º) O que a Lovable já mostra na página atual (link/badge/atributo)
    // 2º) A página de settings do Git do projeto, lida num iframe oculto
    //     (mesma origem, então dá pra ler) — é onde o vínculo real fica
    let detected = detectRepoFromLovable();

    if (!detected) {
      const pid = getLovableProjectId();
      if (pid) {
        ghRepoList.innerHTML = '<div class="lunax-gh-empty">Consultando o repositório vinculado no Lovable...</div>';
        const fromSettings = await findRepoViaSettingsPage(pid);
        if (fromSettings) detected = { full: fromSettings, source: 'settings do Lovable' };
      }
    }

    if (detected) {
      // Confere se esse repositório está mesmo na conta conectada
      const existe = ghAllRepos.some(
        r => r.full_name.toLowerCase() === detected.full.toLowerCase()
      );
      if (existe) {
        const ok = await ghSelectRepo(detected.full, true);
        if (ok) return;
      } else if (ghAllRepos.length) {
        // A Lovable aponta um repo que a conta conectada não enxerga —
        // provavelmente é outra conta GitHub. Avisa em vez de escolher errado.
        ghRenderRepos('');
        ghAutoHint.innerHTML =
          `A Lovable aponta <b>${detected.full}</b>, mas essa conta do GitHub não tem acesso a ele. ` +
          `Troque de conta ou escolha abaixo:`;
        ghAutoHint.style.display = 'block';
        return;
      }
    }

    // 2º) Reserva: casa o nome do projeto com o nome do repositório
    const projectName = getLovableProjectName();
    const match = findMatchingRepo(ghAllRepos, projectName);
    if (match) {
      const ok = await ghSelectRepo(match.full_name, true);
      if (ok) return;
    }

    // Sem certeza: mostra a lista e explica o porquê
    ghRenderRepos('');
    if (projectName) {
      ghAutoHint.textContent = `Não identifiquei com certeza o repositório de "${projectName}". Escolha abaixo:`;
      ghAutoHint.style.display = 'block';
    }
  }

  ghRepoFilter?.addEventListener('input', () => ghRenderRepos(ghRepoFilter.value));

  ghRepoList?.addEventListener('click', async (e) => {
    const btn = e.target.closest('.lunax-gh-repo-item');
    if (!btn) return;
    await ghSelectRepo(btn.dataset.repo, false);
  });

  ghConfirmRepoBtn?.addEventListener('click', async () => {
    if (!ghPendingRepo || !ghBranchSelect.value) {
      ghShowMsg('Escolha o repositório e a branch.', true);
      return;
    }
    ghConfirmRepoBtn.disabled = true;
    const text = ghConfirmRepoBtn.querySelector('.btn-text');
    const spinner = ghConfirmRepoBtn.querySelector('.btn-spinner');
    if (text) text.textContent = 'Verificando permissão...';
    if (spinner) spinner.style.display = 'inline-block';
    try {
      const { data } = await ghCallRepos({
        action: 'select',
        repoFullName: ghPendingRepo,
        branch: ghBranchSelect.value
      });
      if (!data.ok) {
        ghShowMsg(data.error || 'Falha ao salvar repositório e branch.', true);
        return;
      }
      ghActiveRepo = data.selectedRepo;
      ghRepoName.textContent = `${data.selectedRepo} · ${data.selectedBranch}`;
      ghBranchBox.style.display = 'none';
      ghShowState('ready');
      ghShowMsg('');
    } catch (error) {
      ghShowMsg(error?.message || 'Falha ao verificar permissão.', true);
    } finally {
      ghConfirmRepoBtn.disabled = false;
      if (text) text.textContent = 'Usar repositório e branch';
      if (spinner) spinner.style.display = 'none';
    }
  });

  ghChangeRepoBtn?.addEventListener('click', () => {
    ghRenderRepos('');
    ghPendingRepo = null;
    ghBranchBox.style.display = 'none';
    ghAutoHint.style.display = 'none';
    ghShowState('repos');
  });

  ghConnectBtn?.addEventListener('click', async () => {
    ghConnectBtn.disabled = true;
    ghConnectBtn.querySelector('.btn-text').textContent = 'Abrindo GitHub...';
    try {
      const auth = await ghAuth();
      const res = await fetch(cfgUrl('GITHUB_OAUTH_FUNCTION', 'github-oauth') + '?action=start', {
        method: 'GET',
        headers: cfgHeaders(auth.sessionToken, auth.deviceId)
      });
      const data = await res.json().catch(() => ({}));
      if (data.ok && data.connected) {
        await ghOpen();
        return;
      }
      if (!data.ok || !data.url) {
        ghShowMsg(data.error || 'Falha ao iniciar conexão.', true);
        return;
      }
      const popup = window.open(data.url, '_blank', 'width=980,height=760');
      if (!popup) {
        ghShowMsg('O navegador bloqueou a janela do GitHub. Permita pop-ups para lovable.dev e tente novamente.', true);
        return;
      }
      // O GitHub pode isolar a janela com COOP e cortar window.opener.
      // Por isso usamos postMessage quando disponível e também polling seguro.
      let completed = false;
      let pollTimer = null;
      const finishConnection = () => {
        if (completed) return;
        completed = true;
        window.removeEventListener('message', onMsg);
        if (pollTimer) clearInterval(pollTimer);
        setTimeout(ghOpen, 350);
      };
      const onMsg = (ev) => {
        if (!['https://htzhueodeeciczhgnyxt.supabase.co'].includes(ev.origin)) return;
        if (ev.data?.type === 'LUNAX_GITHUB_CONNECTED') {
          finishConnection();
        } else if (ev.data?.type === 'LUNAX_GITHUB_ERROR') {
          completed = true;
          window.removeEventListener('message', onMsg);
          if (pollTimer) clearInterval(pollTimer);
          ghShowMsg(ev.data?.message || 'Falha ao conectar GitHub.', true);
        }
      };
      window.addEventListener('message', onMsg);
      let attempts = 0;
      pollTimer = setInterval(async () => {
        if (completed) return;
        attempts += 1;
        if (attempts > 120) {
          completed = true;
          clearInterval(pollTimer);
          window.removeEventListener('message', onMsg);
          ghShowMsg('A conexão demorou demais. Feche a janela e tente novamente.', true);
          return;
        }
        try {
          const check = await fetch(
            cfgUrl('GITHUB_OAUTH_FUNCTION', 'github-oauth') + '?action=status',
            {
              method: 'GET',
              headers: cfgHeaders(auth.sessionToken, auth.deviceId)
            }
          );
          const status = await check.json().catch(() => ({}));
          if (status.ok && status.connected) finishConnection();
          else if (popup?.closed && attempts > 3) {
            completed = true;
            clearInterval(pollTimer);
            window.removeEventListener('message', onMsg);
            ghShowMsg('A autorização foi fechada antes de concluir.', true);
          }
        } catch (_) {
          // Uma falha transitória não interrompe a autorização.
        }
      }, 1500);
    } catch (err) {
      ghShowMsg('Erro ao conectar: ' + (err?.message || err), true);
    } finally {
      ghConnectBtn.disabled = false;
      ghConnectBtn.querySelector('.btn-text').textContent = 'Conectar GitHub';
    }
  });

  ghSwitchBtn?.addEventListener('click', async () => {
    ghShowMsg('Desconectando...');
    try {
      const auth = await ghAuth();
      const res = await fetch(cfgUrl('GITHUB_OAUTH_FUNCTION', 'github-oauth') + '?action=disconnect', {
        method: 'POST',
        headers: cfgHeaders(auth.sessionToken, auth.deviceId),
        body: JSON.stringify({})
      });
      const data = await res.json().catch(() => ({}));
      if (!data.ok) { ghShowMsg(data.error || 'Falha ao desconectar.', true); return; }
      ghAllRepos = []; ghActiveRepo = null;
      ghShowMsg('');
      ghShowState('disconnected');
    } catch (err) {
      ghShowMsg('Erro: ' + (err?.message || err), true);
    }
  });

  // textarea cresce até um limite
  ghPrompt?.addEventListener('input', () => {
    ghPrompt.style.height = 'auto';
    ghPrompt.style.height = Math.min(ghPrompt.scrollHeight, 120) + 'px';
  });
  ghPrompt?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ghSendBtn.click(); }
  });

  // ══════════════════════════════════════════════════════════════════
  // SELETOR VISUAL DE ELEMENTOS
  // A prévia da Lovable roda num iframe de outro domínio
  // (*.lovable.app), então não dá pra tocar no DOM dela daqui.
  // A conversa é por postMessage com o lunax-frame-selector.js, que o
  // Chrome injeta dentro do iframe.
  //
  //   parent → frame : LUNAX_FRAME_START_SELECT / LUNAX_FRAME_CANCEL_SELECT
  //   frame → parent : LUNAX_FRAME_READY / LUNAX_FRAME_ELEMENT_SELECTED
  // ══════════════════════════════════════════════════════════════════
  const MSG_START     = 'LUNAX_FRAME_START_SELECT';
  const MSG_CANCEL    = 'LUNAX_FRAME_CANCEL_SELECT';
  const MSG_SELECTED  = 'LUNAX_FRAME_ELEMENT_SELECTED';
  const MSG_READY     = 'LUNAX_FRAME_READY';

  const selChip   = root.querySelector('#lunaxSelChip');
  const ghPickBtn = root.querySelector('#lunaxGhPickBtn');

  let selState = 'idle';       // idle | selecting | selected
  let selContext = null;       // contexto do elemento escolhido
  let previewPageContext = null;
  const previewReportWaiters = new Map();

  function findPreviewIframe() {
    const byDomain = Array.from(document.querySelectorAll('iframe')).find(f =>
      f.src && (f.src.includes('lovable.app') || f.src.includes('lovableproject.com'))
    );
    if (byDomain) return byDomain;
    // fallback: iframe visível grande o bastante pra ser a prévia
    return Array.from(document.querySelectorAll('iframe')).find(f => {
      if (!f.contentWindow) return false;
      const r = f.getBoundingClientRect();
      return r.width > 300 && r.height > 300;
    }) || null;
  }

  async function postToFrame(type, payload = {}) {
    try {
      const response = await window.blackSharkPageMessage?.({
        type: 'black-shark-frame-command',
        command: type,
        payload,
      });
      return Boolean(response?.ok);
    } catch (_) {
      return false;
    }
  }

  function previewContextFromUrl(rawUrl) {
    try {
      const url = new URL(rawUrl);
      return {
        pageUrl: url.href,
        pagePath:
          url.searchParams.get('path') ||
          url.searchParams.get('route') ||
          url.searchParams.get('pathname') ||
          url.pathname ||
          '/'
      };
    } catch (_) {
      return null;
    }
  }

  async function getPreviewPageContext() {
    const fallback = previewContextFromUrl(window.BLACK_SHARK_PAGE?.previewUrl || '');
    const sent = await postToFrame('LUNAX_GET_PAGE_CONTEXT');
    if (!sent) return previewPageContext || fallback;
    for (let attempt = 0; attempt < 6; attempt += 1) {
      await new Promise(resolve => setTimeout(resolve, 100));
      if (previewPageContext?.pagePath) return previewPageContext;
    }
    return previewPageContext || fallback;
  }

  async function getPreviewInspection(timeoutMs = 1800) {
    const requestId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    let finish;
    const reportPromise = new Promise(resolve => { finish = resolve; });
    const timer = setTimeout(() => {
      previewReportWaiters.delete(requestId);
      finish(null);
    }, timeoutMs);
    previewReportWaiters.set(requestId, report => {
      clearTimeout(timer);
      finish(report || null);
    });
    const sent = await postToFrame('LUNAX_FRAME_INSPECT_PREVIEW', { requestId });
    if (!sent) {
      clearTimeout(timer);
      previewReportWaiters.delete(requestId);
      finish(null);
    }
    return await reportPromise;
  }

  // Injeta o script no iframe caso o Chrome não tenha injetado sozinho
  // (acontece quando o iframe já estava carregado antes da extensão).
  async function ensureFrameScript() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tabId = window.BLACK_SHARK_PAGE?.tabId || tabs[0]?.id;
      if (!tabId) return;
      const check = await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        func: () => (window.__lunaxFrameSelectorActive === true || window.__vtxFrameSelectorActive === true),
      }).catch(() => null);
      if (check?.some(r => r.result === true)) return;
      await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: ['lunax-frame-selector.js'],
      }).catch(() => {});
      await new Promise(r => setTimeout(r, 300));
    } catch (_) { /* segue sem travar */ }
  }

  function renderSelChip() {
    if (!selChip) return;
    selChip.textContent = '';
    if (!selContext) {
      selChip.style.display = 'none';
      return;
    }
    const c = selContext;
    const txt = (c.text || '').trim();
    const label = txt
      ? `"${txt.slice(0, 38)}${txt.length > 38 ? '…' : ''}"`
      : (c.id ? `#${c.id}` : (c.tag || 'elemento'));
    selChip.style.display = 'flex';
    const icon = document.createElement('span');
    icon.className = 'chip-ico';
    icon.textContent = '🎯';
    const tag = document.createElement('span');
    tag.className = 'chip-tag';
    tag.textContent = String(c.tag || '').toUpperCase();
    const labelNode = document.createElement('span');
    labelNode.className = 'chip-label';
    labelNode.textContent = label;
    const clearButton = document.createElement('button');
    clearButton.type = 'button';
    clearButton.className = 'chip-x';
    clearButton.id = 'lunaxSelClear';
    clearButton.title = 'Remover seleção';
    clearButton.textContent = '×';
    selChip.append(icon, tag, labelNode, clearButton);
  }

  function clearSelection() {
    selContext = null;
    selState = 'idle';
    ghPickBtn?.classList.remove('active');
    renderSelChip();
  }

  selChip?.addEventListener('click', (e) => {
    if (e.target.id === 'lunaxSelClear') clearSelection();
  });

  async function startSelection() {
    if (selState === 'selecting') { stopSelection(); return; }
    selState = 'selecting';
    ghPickBtn?.classList.add('active');
    ghShowMsg('Clique num elemento da prévia. ESC cancela.');

    await ensureFrameScript();
    // manda algumas vezes: o script pode ainda estar subindo
    const ping = () => postToFrame(MSG_START);
    if (!(await ping())) {
      ghShowMsg('Prévia não encontrada. Abra um projeto com a prévia visível.', true);
      selState = 'idle';
      ghPickBtn?.classList.remove('active');
      return;
    }
    setTimeout(ping, 350);
    setTimeout(ping, 900);
  }

  function stopSelection() {
    postToFrame(MSG_CANCEL);
    if (selState === 'selecting') selState = selContext ? 'selected' : 'idle';
    ghPickBtn?.classList.remove('active');
    ghShowMsg('');
  }

  ghPickBtn?.addEventListener('click', startSelection);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && selState === 'selecting') stopSelection();
  });

  function handlePreviewEvent(data) {
    if (!data || typeof data.type !== 'string') return;
    const e = { data };

    if ((e.data.type === MSG_READY || e.data.type === 'VTX_FRAME_READY') && selState === 'selecting') {
      postToFrame(MSG_START);
    }
    if (e.data.type === 'LUNAX_PAGE_CONTEXT') {
      previewPageContext = {
        pageUrl: String(e.data.pageUrl || ''),
        pagePath: String(e.data.pagePath || ''),
      };
    }
    if (e.data.type === 'LUNAX_FRAME_PREVIEW_REPORT') {
      const waiter = previewReportWaiters.get(String(e.data.requestId || ''));
      if (waiter) {
        previewReportWaiters.delete(String(e.data.requestId || ''));
        waiter(e.data.report || null);
      }
    }
    if (e.data.type === MSG_SELECTED || e.data.type === 'VTX_FRAME_ELEMENT_SELECTED') {
      selContext = e.data.context || null;
      selState = selContext ? 'selected' : 'idle';
      ghPickBtn?.classList.remove('active');
      ghShowMsg('');
      renderSelChip();
    }
    if ((e.data.type === MSG_CANCEL || e.data.type === 'VTX_FRAME_CANCEL_SELECT') && selState === 'selecting') {
      selState = selContext ? 'selected' : 'idle';
      ghPickBtn?.classList.remove('active');
      ghShowMsg('');
    }
  }

  chrome.runtime.onMessage.addListener((message, sender) => {
    if (sender.id === chrome.runtime.id && message?.type === 'black-shark-preview-event') {
      handlePreviewEvent(message.payload);
    }
  });

  // ── Anexos: imagem de referência ou arquivo de texto ───────────────
  // Imagens vão pra IA com visão (ela "vê" o print/mockup).
  // Arquivos de texto entram como contexto extra no pedido.
  const ghAttachBtn  = root.querySelector('#lunaxGhAttachBtn');
  const ghFileInput  = root.querySelector('#lunaxGhFileInput');
  const ghAttachList = root.querySelector('#lunaxGhAttachList');

  const MAX_ANEXOS = 4;
  const MAX_BYTES  = 5 * 1024 * 1024;   // 5 MB por arquivo
  let ghAnexos = [];                    // [{name, mimeType, isImage, dataUrl|text}]

  function renderAnexos() {
    if (!ghAttachList) return;
    ghAttachList.textContent = '';
    if (!ghAnexos.length) {
      ghAttachList.style.display = 'none';
      return;
    }
    ghAttachList.style.display = 'flex';
    ghAnexos.forEach((attachment, index) => {
      const chip = document.createElement('div');
      chip.className = 'lunax-attach-chip';
      if (attachment.isImage) {
        const image = document.createElement('img');
        image.src = attachment.dataUrl;
        image.alt = '';
        chip.appendChild(image);
      } else {
        const icon = document.createElement('span');
        icon.className = 'attach-ico';
        icon.textContent = '📄';
        chip.appendChild(icon);
      }
      const name = document.createElement('span');
      name.className = 'attach-name';
      name.textContent = attachment.name;
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'attach-x';
      remove.dataset.i = String(index);
      remove.title = 'Remover';
      remove.textContent = '×';
      chip.append(name, remove);
      ghAttachList.appendChild(chip);
    });
  }

  function lerArquivo(file, comoTexto) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(fr.result);
      fr.onerror = reject;
      comoTexto ? fr.readAsText(file) : fr.readAsDataURL(file);
    });
  }

  ghAttachBtn?.addEventListener('click', () => ghFileInput?.click());

  ghFileInput?.addEventListener('change', async () => {
    const files = Array.from(ghFileInput.files || []);
    ghFileInput.value = '';   // permite reescolher o mesmo arquivo depois

    // ZIP não é suportado por enquanto — avisa em vez de falhar calado
    const zip = files.find(f => /\.zip$/i.test(f.name) || f.type === 'application/zip');
    if (zip) {
      ghShowMsg('Arquivos .zip ainda não são suportados. Envie imagens ou arquivos de texto.', true);
      return;
    }

    if (ghAnexos.length + files.length > MAX_ANEXOS) {
      ghShowMsg(`Máximo de ${MAX_ANEXOS} anexos por pedido.`, true);
      return;
    }

    for (const f of files) {
      if (f.size > MAX_BYTES) {
        ghShowMsg(`"${f.name}" passa de 5 MB.`, true);
        continue;
      }
      const isImage = f.type.startsWith('image/');
      try {
        if (isImage) {
          if (!['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(f.type)) {
            ghShowMsg(`"${f.name}" não é PNG, JPEG, WebP ou GIF.`, true);
            continue;
          }
          ghAnexos.push({ name: f.name, mimeType: f.type, isImage: true, dataUrl: await lerArquivo(f, false) });
        } else {
          const text = String(await lerArquivo(f, true));
          if (text.includes('\u0000')) {
            ghShowMsg(`"${f.name}" parece ser binário. Envie um arquivo de texto ou imagem suportada.`, true);
            continue;
          }
          ghAnexos.push({ name: f.name, mimeType: f.type || 'text/plain', isImage: false, text });
        }
      } catch (_) {
        ghShowMsg(`Não consegui ler "${f.name}".`, true);
      }
    }
    renderAnexos();
  });

  ghAttachList?.addEventListener('click', (e) => {
    const btn = e.target.closest('.attach-x');
    if (!btn) return;
    ghAnexos.splice(Number(btn.dataset.i), 1);
    renderAnexos();
  });

  ghSendBtn?.addEventListener('click', async () => {
    const prompt = (ghPrompt.value || '').trim();
    if (!prompt && !ghAnexos.length) {
      ghShowMsg('Descreva o que você quer alterar (ou anexe uma imagem de referência).', true);
      return;
    }

    ghSendBtn.disabled = true;
    ghSendBtn.querySelector('.send-icon').style.display = 'none';
    ghSendBtn.querySelector('.send-spinner').style.display = 'inline-block';
    ghShowMsg('');
    ghResult.style.display = 'none';

    try {
      const auth = await ghAuth();
      // O modo agente foi descontinuado. O fluxo direto cria o commit na branch
      // selecionada e mantém a revisão no GitHub/Lovable.
      const useAgent = false;
      const currentPreviewContext = await getPreviewPageContext();
      const previewInspection = await getPreviewInspection();
      const selectedContext = selContext
        ? { ...currentPreviewContext, ...selContext, previewInspection }
        : { ...(currentPreviewContext || {}), previewInspection };
      const commonRequest = {
        lovableProjectId: auth.lovableProjectId,
        prompt: prompt || 'Aplique no site o que a imagem anexada mostra.',
        selectedElement: selectedContext || null,
        attachments: ghAnexos.map(a => a.isImage
          ? { name: a.name, mimeType: a.mimeType, isImage: true, dataUrl: a.dataUrl }
          : { name: a.name, mimeType: a.mimeType, isImage: false, text: a.text })
      };

      ghShowMsg('Lendo os arquivos relevantes do repositório...');
      const prepareResult = await aiRequest(
        cfgUrl('GITHUB_AI_EDIT_FUNCTION', 'github-ai-edit'),
        {
          method: 'POST',
          headers: cfgHeaders(auth.sessionToken, auth.deviceId),
          body: JSON.stringify({
            action: useAgent ? 'agent_prepare' : 'prepare',
            ...commonRequest
          })
        }
      );
      const prepareRes = prepareResult.response;
      const prepareData = prepareResult.data;
      if (!prepareData.ok || !prepareData.prepared) {
        ghShowMsg(
          prepareData.error || `Falha ao ler o repositório (HTTP ${prepareRes.status}).`,
          true
        );
        return;
      }

      const agentJobId = prepareData.job?.id || null;
      ghShowMsg('Gerando a alteração e preparando o commit...');
      const requestBody = JSON.stringify({
        action: useAgent ? 'agent_generate' : 'generate',
        jobId: agentJobId,
        ...commonRequest,
        prepared: prepareData.prepared
      });

      const generatedResult = await aiRequest(cfgUrl('GITHUB_AI_EDIT_FUNCTION', 'github-ai-edit'), {
        method: 'POST',
        headers: cfgHeaders(auth.sessionToken, auth.deviceId),
        body: requestBody
      });
      const res = generatedResult.response;
      const data = generatedResult.data;

      if (!data.ok) {
        const resourceLimit = res.status === 546 || data.code === 'WORKER_RESOURCE_LIMIT';
        ghShowMsg(
          data.code === 'AI_QUOTA_EXHAUSTED'
            ? (data.error || 'A franquia do provedor de IA foi atingida. Aguarde o horário de renovação informado.')
            : data.code === 'AI_OVERLOADED' || resourceLimit
            ? 'O provedor de IA está temporariamente indisponível. Tente novamente em alguns segundos; nenhum commit parcial foi criado.'
            : (data.error || `Falha ao processar o pedido (HTTP ${res.status}).`),
          true
        );
        return;
      }

      ghResult.style.display = 'block';
      ghResult.textContent = '';
      const title = document.createElement('div');
      title.textContent = `✅ Commit ${(data.commit_sha || '').slice(0, 7)} — ${(data.files_changed || []).length} arquivo(s).`;
      const commitLink = document.createElement('a');
      commitLink.href = data.commit_url;
      commitLink.target = '_blank';
      commitLink.rel = 'noopener noreferrer';
      commitLink.textContent = 'Abrir commit no GitHub';
      const sync = document.createElement('small');
      sync.textContent = data.pull_request
        ? ' A branch é protegida. Mescle o Pull Request para aparecer no Lovable.'
        : ` Enviado para ${data.repo}@${data.branch}. O Lovable sincroniza quando esta é a branch ativa.`;
      ghResult.append(title, commitLink, document.createElement('br'), sync);
      if (data.pull_request?.url) {
        const prLink = document.createElement('a');
        prLink.href = data.pull_request.url;
        prLink.target = '_blank';
        prLink.rel = 'noopener noreferrer';
        prLink.textContent = `Abrir Pull Request #${data.pull_request.number}`;
        ghResult.append(document.createElement('br'), prLink);
      }
      clearSelection();
      ghAnexos = [];
      renderAnexos();
      ghPrompt.value = '';
      ghPrompt.style.height = 'auto';

      // Contabiliza comando + economia no painel
      const n = (parseInt(commandsCountEl.textContent, 10) || 0) + 1;
      commandsCountEl.textContent = String(n);
      savingsAmountEl.textContent = `R$ ${(n * 2).toFixed(2).replace('.', ',')}`;
    } catch (err) {
      ghShowMsg('Erro: ' + (err?.message || err), true);
    } finally {
      ghSendBtn.disabled = false;
      ghSendBtn.querySelector('.send-icon').style.display = '';
      ghSendBtn.querySelector('.send-spinner').style.display = 'none';
    }
  });

  // ══════════════════════════════════════════════════════════════════
  // BANCO DE DADOS (Supabase do cliente)
  // Regra central: a extensão NUNCA executa SQL direto. Sempre gera,
  // mostra pro cliente revisar, e só aplica quando ele confirma.
  // Comandos que podem perder dados exigem uma segunda confirmação.
  // ══════════════════════════════════════════════════════════════════
  const dbBar        = root.querySelector('#lunaxDbBar');
  const dbDisc       = root.querySelector('#lunaxDbDisconnected');
  const dbProjects   = root.querySelector('#lunaxDbProjects');
  const dbReady      = root.querySelector('#lunaxDbReady');
  const dbConnectBtn = root.querySelector('#lunaxDbConnectBtn');
  const dbSwitchBtn  = root.querySelector('#lunaxDbSwitchBtn');
  const dbProjectList= root.querySelector('#lunaxDbProjectList');
  const dbProjectName= root.querySelector('#lunaxDbProjectName');
  const dbChangeBtn  = root.querySelector('#lunaxDbChangeProjectBtn');
  const dbPrompt     = root.querySelector('#lunaxDbPrompt');
  const dbGenBtn     = root.querySelector('#lunaxDbGenBtn');
  const dbPreview    = root.querySelector('#lunaxDbPreview');
  const dbExplain    = root.querySelector('#lunaxDbExplain');
  const dbSqlEl      = root.querySelector('#lunaxDbSql');
  const dbWarn       = root.querySelector('#lunaxDbWarn');
  const dbApplyBtn   = root.querySelector('#lunaxDbApplyBtn');
  const dbCancelBtn  = root.querySelector('#lunaxDbCancelBtn');
  const dbMsg        = root.querySelector('#lunaxDbMsg');
  const dbResult     = root.querySelector('#lunaxDbResult');

  let dbPendingSql = null;
  let dbPendingDestructive = false;

  function dbShowMsg(t, err) {
    if (!dbMsg) return;
    if (!t) { dbMsg.style.display = 'none'; dbMsg.textContent = ''; return; }
    dbMsg.textContent = t;
    dbMsg.className = err ? 'lunax-gh-msg error' : 'lunax-gh-msg';
    dbMsg.style.display = 'block';
  }
  function dbState(n) {
    dbBar.style.display = 'flex';
    dbDisc.style.display     = n === 'disconnected' ? 'flex' : 'none';
    dbProjects.style.display = n === 'projects'     ? 'flex' : 'none';
    dbReady.style.display    = n === 'ready'        ? 'flex' : 'none';
  }
  function dbClose() { dbBar.style.display = 'none'; dbShowMsg(''); }
  root.querySelectorAll('[data-db-close]').forEach(b => b.addEventListener('click', dbClose));

  async function dbCall(payload) {
    const auth = await ghAuth();
    const cfg = window.LUNAX_CONFIG || window.VERTEX_CONFIG || {};
    const oauthActions = new Set(['status', 'projects', 'select_project']);
    const functionName = oauthActions.has(payload?.action) ? 'supabase-oauth' : 'supabase-db';
    const normalizedPayload = payload?.action === 'select_project'
      ? { action: 'select_project', project_ref: payload.projectRef }
      : payload;
    const res = await fetch(`${cfg.SUPABASE_URL}/functions/v1/${functionName}`, {
      method: 'POST', headers: cfgHeaders(auth.sessionToken, auth.deviceId),
      body: JSON.stringify({ ...normalizedPayload })
    });
    return await res.json().catch(() => ({}));
  }

  function dbRenderProjects(list) {
    if (!list?.length) {
      dbProjectList.innerHTML = '<div class="lunax-gh-empty">Nenhum projeto encontrado nessa conta.</div>';
      return;
    }
    dbProjectList.innerHTML = list.map(p => `
      <button class="lunax-gh-repo-item" data-ref="${p.ref}" data-name="${p.name}">
        <span class="repo-name">${p.name}</span>
      </button>`).join('');
  }

  async function dbOpen() {
    if (!isLicensed) { openPanelFlow(); return; }
    dbState('projects');
    dbProjectList.innerHTML = '<div class="lunax-gh-empty">Carregando...</div>';
    const data = await dbCall({ action: 'status' });

    if (!data.ok) {
      if (data.code === 'NOT_CONNECTED') { dbState('disconnected'); return; }
      dbProjectList.innerHTML = `<div class="lunax-gh-empty">${data.error || 'Falha ao carregar.'}</div>`;
      return;
    }
    if (data.project_ref) {
      dbProjectName.textContent = data.project_name || data.project_ref;
      dbState('ready');
      return;
    }
    const projects = await dbCall({ action: 'projects' });
    if (!projects.ok) {
      dbProjectList.innerHTML = `<div class="lunax-gh-empty">${projects.error || 'Falha ao listar projetos.'}</div>`;
      return;
    }
    dbRenderProjects(projects.projects);
  }

  dbProjectList?.addEventListener('click', async (e) => {
    const btn = e.target.closest('.lunax-gh-repo-item');
    if (!btn) return;
    const d = await dbCall({ action: 'select_project', projectRef: btn.dataset.ref, projectName: btn.dataset.name });
    if (!d.ok) { dbShowMsg(d.error || 'Falha ao selecionar.', true); return; }
    dbProjectName.textContent = btn.dataset.name;
    dbState('ready');
  });

  dbChangeBtn?.addEventListener('click', async () => {
    dbState('projects');
    dbProjectList.innerHTML = '<div class="lunax-gh-empty">Carregando...</div>';
    const d = await dbCall({ action: 'projects' });
    dbRenderProjects(d.projects);
  });

  dbConnectBtn?.addEventListener('click', async () => {
    const auth = await ghAuth();
    dbConnectBtn.disabled = true;
    const txt = dbConnectBtn.querySelector('.btn-text');
    const original = txt ? txt.textContent : '';
    if (txt) txt.textContent = 'Abrindo Supabase...';
    dbShowMsg('');
    try {
      const cfg = window.LUNAX_CONFIG || window.VERTEX_CONFIG || {};
      const res = await fetch(`${cfg.SUPABASE_URL}/functions/v1/supabase-oauth?action=start`, {
        method: 'POST', headers: cfgHeaders(auth.sessionToken, auth.deviceId), body: JSON.stringify({})
      });
      const d = await res.json().catch(() => ({}));

      if (!d.ok || !d.authorize_url) {
        dbShowMsg(d.error || `Falha ao iniciar a conexão (HTTP ${res.status}).`, true);
        return;
      }

      const win = window.open(d.authorize_url, '_blank', 'width=980,height=760');
      if (!win) {
        // popup bloqueado é comum no celular — oferece o link direto
        dbShowMsg('O navegador bloqueou a janela. Toque no link para autorizar.', true);
        dbResult.style.display = 'block';
        dbResult.innerHTML = `<a href="${d.authorize_url}" target="_blank" rel="noopener noreferrer">Abrir autorização do Supabase</a>`;
        return;
      }

      const onMsg = (ev) => {
        if (ev.data?.type === 'LUNAX_SUPABASE_CONNECTED' || ev.data?.type === 'VERTEX_SUPABASE_CONNECTED') {
          window.removeEventListener('message', onMsg);
          dbShowMsg('');
          setTimeout(dbOpen, 500);
        }
      };
      window.addEventListener('message', onMsg);
    } catch (err) {
      dbShowMsg('Erro de conexão: ' + (err?.message || err), true);
    } finally {
      dbConnectBtn.disabled = false;
      if (txt) txt.textContent = original || 'Conectar Supabase';
    }
  });

  dbSwitchBtn?.addEventListener('click', async () => {
    const auth = await ghAuth();
    const cfg = window.LUNAX_CONFIG || window.VERTEX_CONFIG || {};
    await fetch(`${cfg.SUPABASE_URL}/functions/v1/supabase-oauth?action=disconnect`, {
      method: 'POST', headers: cfgHeaders(auth.sessionToken, auth.deviceId), body: JSON.stringify({})
    }).catch(() => {});
    dbState('disconnected');
  });

  // Etapa 1: gerar o SQL (não executa nada)
  dbGenBtn?.addEventListener('click', async () => {
    const prompt = (dbPrompt.value || '').trim();
    if (!prompt) { dbShowMsg('Descreva o que você quer no banco.', true); return; }
    dbGenBtn.disabled = true;
    dbGenBtn.querySelector('.send-icon').style.display = 'none';
    dbGenBtn.querySelector('.send-spinner').style.display = 'inline-block';
    dbShowMsg('');
    dbPreview.style.display = 'none';
    dbResult.style.display = 'none';

    try {
      const d = await dbCall({ action: 'generate', prompt });
      if (!d.ok) { dbShowMsg(d.error || 'Falha ao gerar o SQL.', true); return; }

      if (d.blocked) {
        dbShowMsg('Esse pedido não é permitido: ' + (d.reasons || []).join('; '), true);
        return;
      }

      dbPendingSql = d.sql;
      dbPendingDestructive = !!d.destructive;
      dbExplain.textContent = d.explicacao || '';
      dbSqlEl.textContent = d.sql;

      if (d.destructive) {
        dbWarn.style.display = 'block';
        dbWarn.innerHTML = '⚠️ <b>Atenção:</b> esse comando pode apagar dados.<br>' +
          (d.reasons || []).map(r => '• ' + r).join('<br>');
        dbApplyBtn.textContent = 'Confirmo, aplicar mesmo assim';
        dbApplyBtn.classList.add('danger');
      } else {
        dbWarn.style.display = 'none';
        dbApplyBtn.textContent = 'Aplicar no banco';
        dbApplyBtn.classList.remove('danger');
      }
      dbPreview.style.display = 'block';
    } catch (err) {
      dbShowMsg('Erro: ' + (err?.message || err), true);
    } finally {
      dbGenBtn.disabled = false;
      dbGenBtn.querySelector('.send-icon').style.display = '';
      dbGenBtn.querySelector('.send-spinner').style.display = 'none';
    }
  });

  dbCancelBtn?.addEventListener('click', () => {
    dbPreview.style.display = 'none';
    dbPendingSql = null;
  });

  // Etapa 2: aplicar (só depois da revisão)
  dbApplyBtn?.addEventListener('click', async () => {
    if (!dbPendingSql) return;
    dbApplyBtn.disabled = true;
    dbApplyBtn.textContent = 'Aplicando...';
    try {
      const d = await dbCall({
        action: 'apply',
        sql: dbPendingSql,
        prompt: (dbPrompt.value || '').trim(),
        confirmDestructive: dbPendingDestructive,
      });

      if (!d.ok) {
        if (d.blocked) dbShowMsg('Bloqueado: ' + (d.reasons || []).join('; '), true);
        else dbShowMsg(d.error || 'Falha ao aplicar.', true);
        return;
      }

      dbPreview.style.display = 'none';
      dbResult.style.display = 'block';
      dbResult.innerHTML = '✅ Aplicado no banco com sucesso.' +
        (d.was_destructive ? '<br><small>Comando destrutivo — registrado no log.</small>' : '');
      dbPrompt.value = '';
      dbPendingSql = null;
    } catch (err) {
      dbShowMsg('Erro: ' + (err?.message || err), true);
    } finally {
      dbApplyBtn.disabled = false;
    }
  });

  // Aviso rápido no canto da tela.
  let toastEl = null, toastTimer = null;
  function showDockToast(texto) {
    if (!toastEl || !document.body.contains(toastEl)) {
      toastEl = document.createElement('div');
      toastEl.id = 'lunax-toast';
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = texto;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastEl?.classList.remove('show'); }, 2600);
  }

  // ══════════════════════════════════════════════════════════════════
  // BLOQUEIO DO CHAT NATIVO DA LOVABLE
  // Evita o cliente mandar comando por engano no chat deles e gastar
  // créditos. O bloqueio é feito com uma camada por cima + intercepção
  // de teclas — sem alterar o DOM da Lovable, então é 100% reversível.
  // ══════════════════════════════════════════════════════════════════
  const shieldBtn = root.querySelector('#nextDockShield');
  const BLOCK_KEY = 'lunax_chat_bloqueado';

  let chatBloqueado = false;
  let blockOverlay = null;
  let blockPoll = null;

  function acharComposerLovable() {
    const sels = [
      '[data-testid="chat-composer"]',
      '[data-testid="chat-input-wrapper"]',
      '#chat-input',
      'form#chat-input',
    ];
    for (const s of sels) {
      const el = document.querySelector(s);
      if (el && !el.closest('#next-widget-root')) return el;
    }
    // fallback: sobe do textarea até um pai com botões
    const ta = Array.from(document.querySelectorAll('textarea, [contenteditable="true"]'))
      .find(e => !e.closest('#next-widget-root') && e.getBoundingClientRect().width > 150);
    if (!ta) return null;
    let el = ta;
    for (let i = 0; i < 6 && el.parentElement; i++) {
      el = el.parentElement;
      if (el.querySelectorAll('button').length >= 2) break;
    }
    return el;
  }

  function posicionarOverlay() {
    const c = acharComposerLovable();
    if (!c || !blockOverlay) return;
    const r = c.getBoundingClientRect();
    Object.assign(blockOverlay.style, {
      left: `${r.left - 4}px`,
      top: `${r.top - 4}px`,
      width: `${r.width + 8}px`,
      height: `${r.height + 8}px`,
    });
  }

  // Intercepta teclas antes de chegarem no chat da Lovable
  function bloquearTecla(e) {
    if (!chatBloqueado) return;
    const c = acharComposerLovable();
    if (!c) return;
    if (c.contains(e.target)) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
    }
  }

  function ativarBloqueio() {
    const c = acharComposerLovable();
    if (!c) { showDockToast('Chat da Lovable não encontrado nesta tela.'); return false; }

    if (!blockOverlay || !document.body.contains(blockOverlay)) {
      blockOverlay = document.createElement('div');
      blockOverlay.id = 'lunax-chat-block';
      blockOverlay.innerHTML =
        '<span class="lunax-block-tag">' +
        '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2">' +
        '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>' +
        'Chat bloqueado pelo Black Shark</span>';
      document.body.appendChild(blockOverlay);
    }
    // Mostra ANTES de posicionar: se medir enquanto está display:none,
    // as dimensões saem erradas e o overlay não cobre o chat inteiro.
    blockOverlay.style.display = 'flex';
    posicionarOverlay();
    // remede no quadro seguinte, quando o layout já assentou
    requestAnimationFrame(() => requestAnimationFrame(posicionarOverlay));

    // tira o foco caso o cliente já estivesse digitando
    try {
      const ativo = document.activeElement;
      if (ativo && c.contains(ativo)) ativo.blur();
    } catch (_) {}

    document.addEventListener('keydown', bloquearTecla, true);
    document.addEventListener('keypress', bloquearTecla, true);
    document.addEventListener('paste', bloquearTecla, true);

    // o chat pode se mover (scroll, teclado do celular abrindo)
    blockPoll = setInterval(posicionarOverlay, 400);
    window.addEventListener('scroll', posicionarOverlay, true);
    window.addEventListener('resize', posicionarOverlay);
    return true;
  }

  function desativarBloqueio() {
    if (blockOverlay) { blockOverlay.remove(); blockOverlay = null; }
    document.removeEventListener('keydown', bloquearTecla, true);
    document.removeEventListener('keypress', bloquearTecla, true);
    document.removeEventListener('paste', bloquearTecla, true);
    if (blockPoll) { clearInterval(blockPoll); blockPoll = null; }
    window.removeEventListener('scroll', posicionarOverlay, true);
    window.removeEventListener('resize', posicionarOverlay);
  }

  async function aplicarEstadoBloqueio(ligado, avisar) {
    try {
      const result = await window.blackSharkPageMessage?.({
        type: 'black-shark-shield',
        enabled: Boolean(ligado),
      });
      if (!result?.ok) {
        chatBloqueado = false;
        shieldBtn?.classList.remove('ativo');
        if (avisar) showDockToast(result?.error || 'Não foi possível proteger o chat nesta tela.');
        return false;
      }
      chatBloqueado = Boolean(result.enabled);
      shieldBtn?.classList.toggle('ativo', chatBloqueado);
      shieldBtn?.setAttribute(
        'title',
        chatBloqueado ? 'Desbloquear o chat da Lovable' : 'Bloquear o chat da Lovable'
      );
      if (avisar) showDockToast(chatBloqueado ? 'Chat da Lovable bloqueado.' : 'Chat da Lovable liberado.');
      await chrome.storage.local.set({ [BLOCK_KEY]: chatBloqueado });
      return true;
    } catch (_) {
      chatBloqueado = false;
      shieldBtn?.classList.remove('ativo');
      if (avisar) showDockToast('Abra um projeto no Lovable para usar esta proteção.');
      return false;
    }
  }

  shieldBtn?.addEventListener('click', () => aplicarEstadoBloqueio(!chatBloqueado, true));

  // Restaura o estado ao recarregar a página
  chrome.storage.local.get(['lunax_chat_bloqueado', 'vertex_chat_bloqueado']).then((s) => {
    if (s?.lunax_chat_bloqueado || s?.vertex_chat_bloqueado) {
      setTimeout(() => aplicarEstadoBloqueio(true, false), 700);
    }
  }).catch(() => {});

  // O painel principal é lateral e fixo; apenas o launcher permanece móvel.
})();
