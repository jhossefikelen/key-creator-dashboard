(() => {
  if (window.__blackSharkBridge) return;
  window.__blackSharkBridge = true;

  const PREVIEW_EVENT_TYPES = new Set([
    'LUNAX_FRAME_READY',
    'LUNAX_FRAME_CANCEL_SELECT',
    'LUNAX_FRAME_ELEMENT_SELECTED',
    'LUNAX_PAGE_CONTEXT',
    'LUNAX_FRAME_PREVIEW_REPORT',
    'VTX_FRAME_READY',
    'VTX_FRAME_CANCEL_SELECT',
    'VTX_FRAME_ELEMENT_SELECTED',
  ]);

  const previewFrame = () => {
    const frames = Array.from(document.querySelectorAll('iframe'));
    return frames.find((frame) =>
      /https:\/\/[^/]+\.(?:lovable\.app|lovableproject\.com)(?:\/|$)/i.test(frame.src || '')
    ) || frames.find((frame) => {
      const rect = frame.getBoundingClientRect();
      return Boolean(frame.contentWindow && rect.width > 300 && rect.height > 300);
    }) || null;
  };

  const detectRepo = () => {
    const elements = Array.from(document.querySelectorAll(
      'a[href*="github.com/"], [data-repo], [data-repository], [data-github-repo]'
    ));
    for (const element of elements) {
      const values = [
        element.getAttribute('href'),
        element.getAttribute('data-repo'),
        element.getAttribute('data-repository'),
        element.getAttribute('data-github-repo'),
        element.textContent,
      ];
      for (const value of values) {
        const match = String(value || '').match(/(?:github\.com\/)?([A-Za-z0-9][A-Za-z0-9-]*)\/([A-Za-z0-9._-]+)/);
        if (match) return `${match[1]}/${match[2].replace(/\.git$/i, '')}`;
      }
    }
    return null;
  };

  const projectContext = () => {
    const frame = previewFrame();
    return {
      type: 'black-shark-context',
      url: location.href,
      title: (document.title || 'Projeto Lovable').replace(/\s*[-–|]\s*Lovable.*$/i, '').trim(),
      repo: detectRepo(),
      previewUrl: frame?.src || '',
    };
  };

  let shieldEnabled = false;
  let shieldOverlay = null;
  let shieldTimer = null;

  const findComposer = () => {
    const selectors = [
      '[data-testid="chat-composer"]',
      '[data-testid="chat-input-wrapper"]',
      'form#chat-input',
      '#chat-input',
    ];
    for (const selector of selectors) {
      const node = document.querySelector(selector);
      if (node) return node;
    }
    const input = Array.from(document.querySelectorAll('textarea, [contenteditable="true"]'))
      .find((node) => node.getBoundingClientRect().width > 150);
    if (!input) return null;
    let node = input;
    for (let index = 0; index < 6 && node.parentElement; index += 1) {
      node = node.parentElement;
      if (node.querySelectorAll('button').length >= 2) break;
    }
    return node;
  };

  const positionShield = () => {
    const composer = findComposer();
    if (!composer || !shieldOverlay) return false;
    const rect = composer.getBoundingClientRect();
    Object.assign(shieldOverlay.style, {
      left: `${Math.max(0, rect.left - 4)}px`,
      top: `${Math.max(0, rect.top - 4)}px`,
      width: `${rect.width + 8}px`,
      height: `${rect.height + 8}px`,
    });
    return true;
  };

  const stopBlockedInput = (event) => {
    if (!shieldEnabled) return;
    const composer = findComposer();
    if (composer?.contains(event.target)) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }
  };

  const setShield = (enabled) => {
    if (!enabled) {
      shieldEnabled = false;
      shieldOverlay?.remove();
      shieldOverlay = null;
      if (shieldTimer) clearInterval(shieldTimer);
      shieldTimer = null;
      ['keydown', 'keypress', 'beforeinput', 'paste', 'drop'].forEach((type) =>
        document.removeEventListener(type, stopBlockedInput, true)
      );
      window.removeEventListener('scroll', positionShield, true);
      window.removeEventListener('resize', positionShield);
      return { ok: true, enabled: false };
    }

    const composer = findComposer();
    if (!composer) return { ok: false, enabled: false, error: 'Chat da Lovable não encontrado nesta tela.' };
    shieldEnabled = true;
    if (!shieldOverlay) {
      shieldOverlay = document.createElement('div');
      shieldOverlay.id = 'black-shark-chat-shield';
      shieldOverlay.setAttribute('role', 'status');
      shieldOverlay.textContent = '🔒 Chat protegido pela Black Shark';
      Object.assign(shieldOverlay.style, {
        position: 'fixed',
        zIndex: '2147483646',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        border: '1px solid #00d58b',
        borderRadius: '12px',
        background: 'rgba(2, 18, 13, .94)',
        color: '#8fffd0',
        font: '600 12px Segoe UI, sans-serif',
        boxShadow: '0 0 20px rgba(0, 213, 139, .24)',
        cursor: 'not-allowed',
      });
      document.documentElement.appendChild(shieldOverlay);
    }
    positionShield();
    try {
      if (composer.contains(document.activeElement)) document.activeElement.blur();
    } catch (_) {}
    ['keydown', 'keypress', 'beforeinput', 'paste', 'drop'].forEach((type) =>
      document.addEventListener(type, stopBlockedInput, true)
    );
    if (shieldTimer) clearInterval(shieldTimer);
    shieldTimer = setInterval(positionShield, 400);
    window.addEventListener('scroll', positionShield, true);
    window.addEventListener('resize', positionShield);
    return { ok: true, enabled: true };
  };

  window.addEventListener('message', (event) => {
    const frame = previewFrame();
    if (!frame?.contentWindow || event.source !== frame.contentWindow) return;
    if (!event.data || !PREVIEW_EVENT_TYPES.has(event.data.type)) return;
    chrome.runtime.sendMessage({ type: 'black-shark-preview-event', payload: event.data }).catch(() => {});
  });

  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id || !message?.type) return;
    if (message.type === 'black-shark-context') {
      reply(projectContext());
      return;
    }
    if (message.type === 'black-shark-frame-command') {
      const frame = previewFrame();
      if (!frame?.contentWindow) {
        reply({ ok: false, error: 'Prévia do projeto não encontrada.' });
        return;
      }
      frame.contentWindow.postMessage({ type: message.command, ...(message.payload || {}) }, '*');
      reply({ ok: true });
      return;
    }
    if (message.type === 'black-shark-shield') reply(setShield(Boolean(message.enabled)));
  });
})();
