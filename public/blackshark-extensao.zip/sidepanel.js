(() => {
  const status = document.getElementById('black-shark-context');
  const loading = document.getElementById('black-shark-loading');
  const validProject = (url) =>
    /^https:\/\/(?:www\.)?lovable\.dev\/projects\/[0-9a-f-]{36}(?:\/|$|\?)/i.test(url || '');

  let page = { tabId: null, url: '', title: '', repo: null, previewUrl: '' };
  let interfaceLoaded = false;
  window.BLACK_SHARK_PAGE = page;

  async function findProjectTab() {
    const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (validProject(active?.url)) return active;
    const candidates = await chrome.tabs.query({
      currentWindow: true,
      url: ['https://lovable.dev/projects/*', 'https://www.lovable.dev/projects/*'],
    });
    return candidates.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0] || null;
  }

  window.blackSharkPageMessage = async (message) => {
    if (!page.tabId) throw new Error('Abra um projeto no Lovable.');
    try {
      return await chrome.tabs.sendMessage(page.tabId, message);
    } catch (_) {
      const tab = await chrome.tabs.get(page.tabId);
      if (!validProject(tab?.url)) throw new Error('Abra novamente o projeto no Lovable.');
      await chrome.scripting.executeScript({ target: { tabId: page.tabId }, files: ['page-bridge.js'] });
      return chrome.tabs.sendMessage(page.tabId, message);
    }
  };

  window.blackSharkRefreshContext = async () => {
    const context = await window.blackSharkPageMessage({ type: 'black-shark-context' });
    if (!validProject(context?.url)) throw new Error('Abra um projeto válido no Lovable.');
    page = { ...page, ...context };
    window.BLACK_SHARK_PAGE = page;
    status.textContent = `Projeto: ${context.title || 'Lovable'}`;
    status.title = context.url;
    return context;
  };

  async function connect(tab) {
    if (!validProject(tab?.url)) {
      status.textContent = 'Abra seu projeto no Lovable';
      if (!interfaceLoaded) {
        loading.textContent = 'Abra um projeto no Lovable. A Black Shark conecta automaticamente quando o projeto estiver disponível.';
      }
      return;
    }
    page.tabId = tab.id;
    window.BLACK_SHARK_PAGE = page;
    try {
      await window.blackSharkRefreshContext();
      if (interfaceLoaded) return;
      interfaceLoaded = true;
      const script = document.createElement('script');
      script.id = 'black-shark-interface';
      script.src = 'content.js';
      script.onload = () => loading.remove();
      script.onerror = () => {
        interfaceLoaded = false;
        loading.textContent = 'Falha ao carregar a interface. Recarregue a extensão em chrome://extensions.';
      };
      document.body.appendChild(script);
    } catch (error) {
      status.textContent = 'Black Shark';
      loading.textContent = error?.message || 'Não foi possível conectar ao Lovable.';
    }
  }

  findProjectTab().then(connect).catch(() => connect(null));
  chrome.tabs.onActivated.addListener(async ({ tabId }) => {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (tab) connect(tab);
  });
  chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
    if (validProject(tab?.url) && (info.status === 'complete' || info.url)) connect(tab);
  });
})();
