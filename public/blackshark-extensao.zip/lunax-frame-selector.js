// lunax-frame-selector.js — roda DENTRO do iframe *.lovable.app
// (domínio real confirmado via DevTools: id-preview-*.lovable.app)
// Namespace exclusivo lunax-visual-* pra tudo que criamos aqui.
// Comunicação com a página principal (lovable.dev) é EXCLUSIVAMENTE via
// postMessage — nunca tenta acessar o DOM do parent (cross-origin).
// Não importa módulos externos, não altera o DOM do projeto de forma
// permanente, não interfere nos scripts do site dentro do iframe.

(function lunaxFrameSelector() {
  'use strict';

  // Garante que só inicializa uma vez mesmo se o script for injetado
  // mais de uma vez (ex: recarregamento do iframe).
  if (window.__lunaxFrameSelectorActive || window.__vtxFrameSelectorActive) return;
  window.__lunaxFrameSelectorActive = true;
  window.__vtxFrameSelectorActive = true;

  // ── Constantes de protocolo de mensagens ────────────────────────────
  // Só processa mensagens com essa origem para evitar que qualquer página
  // arbitrária possa ativar o seletor.
  const ALLOWED_PARENT_ORIGINS = new Set([
    'https://lovable.dev',
    'https://www.lovable.dev'
  ]);
  let parentOrigin = 'https://lovable.dev';
  const MSG_START     = 'LUNAX_FRAME_START_SELECT';    // parent → frame
  const MSG_CANCEL    = 'LUNAX_FRAME_CANCEL_SELECT';   // parent → frame
  const MSG_SELECTED  = 'LUNAX_FRAME_ELEMENT_SELECTED'; // frame → parent
  const MSG_READY     = 'LUNAX_FRAME_READY';            // frame → parent (handshake)
  const MSG_INSPECT   = 'LUNAX_FRAME_INSPECT_PREVIEW';
  const MSG_INSPECTED = 'LUNAX_FRAME_PREVIEW_REPORT';

  // ── Estado ───────────────────────────────────────────────────────────
  let isSelecting   = false;
  let highlightBox  = null;
  let cancelPill    = null;
  let lastHovered   = null;

  // ── Overlay de destaque ──────────────────────────────────────────────
  function ensureHighlight() {
    if (highlightBox && document.body.contains(highlightBox)) return highlightBox;
    highlightBox = document.createElement('div');
    highlightBox.id = 'lunax-visual-highlight-box';
    // Estilos inline pra não depender de nenhuma folha de estilos do projeto
    Object.assign(highlightBox.style, {
      position: 'fixed',
      zIndex: '2147483000',
      display: 'none',
      border: '2px solid #7c3aed',
      background: 'rgba(124,58,237,0.10)',
      borderRadius: '4px',
      pointerEvents: 'none',
      boxSizing: 'border-box',
      boxShadow: '0 0 0 2px rgba(255,255,255,0.6)',
    });
    document.body.appendChild(highlightBox);
    return highlightBox;
  }

  function positionHighlight(el) {
    const box  = ensureHighlight();
    const rect = el.getBoundingClientRect();
    Object.assign(box.style, {
      left:    rect.left + 'px',
      top:     rect.top  + 'px',
      width:   rect.width  + 'px',
      height:  rect.height + 'px',
      display: 'block',
    });
  }

  function hideHighlight() {
    if (highlightBox) highlightBox.style.display = 'none';
  }

  // ── Pill de cancelar (mobile) ────────────────────────────────────────
  function ensureCancelPill() {
    if (cancelPill && document.body.contains(cancelPill)) return cancelPill;
    cancelPill = document.createElement('button');
    cancelPill.id = 'lunax-visual-cancel-pill';
    Object.assign(cancelPill.style, {
      position:      'fixed',
      zIndex:        '2147483001',
      bottom:        '24px',
      left:          '50%',
      transform:     'translateX(-50%)',
      background:    '#14121c',
      color:         '#fff',
      border:        'none',
      borderRadius:  '999px',
      padding:       '10px 20px',
      fontSize:      '13px',
      fontWeight:    '700',
      fontFamily:    'system-ui,sans-serif',
      cursor:        'pointer',
      display:       'none',
      whiteSpace:    'nowrap',
      boxShadow:     '0 8px 24px rgba(0,0,0,0.3)',
    });
    cancelPill.textContent = '✕ Cancelar seleção';
    cancelPill.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      exitSelectMode();
      window.parent.postMessage({ type: MSG_CANCEL }, parentOrigin);
    });
    document.body.appendChild(cancelPill);
    return cancelPill;
  }

  // ── Coleta de contexto do elemento ──────────────────────────────────
  function sanitizeHtml(el, maxLen) {
    try {
      const clone = el.cloneNode(true);
      clone.querySelectorAll('script,style,iframe').forEach(n => n.remove());
      Array.from(clone.attributes || []).forEach(a => {
        if (/^on/i.test(a.name)) clone.removeAttribute(a.name);
      });
      const h = clone.outerHTML || '';
      return h.length > maxLen ? h.slice(0, maxLen) + '…' : h;
    } catch { return ''; }
  }

  function getComputedStyleSample(el) {
    const cs = window.getComputedStyle(el);
    const keys = ['color','backgroundColor','fontSize','fontWeight',
                  'padding','margin','borderRadius','display','width','height'];
    const out = {};
    keys.forEach(k => { out[k] = cs[k]; });
    return out;
  }

  function collectAncestors(el, depth) {
    const out = []; let node = el.parentElement;
    for (let i = 0; i < depth && node; i++, node = node.parentElement) {
      out.push({
        tag:     (node.tagName || '').toLowerCase(),
        id:      node.id || '',
        classes: typeof node.className === 'string' ? node.className : '',
      });
    }
    return out;
  }

  function extractContext(el) {
    const rect = el.getBoundingClientRect();
    const dataAttrs = {}, ariaAttrs = {};
    Array.from(el.attributes || []).forEach(a => {
      if (a.name.startsWith('data-')) dataAttrs[a.name] = a.value;
      else if (a.name.startsWith('aria-')) ariaAttrs[a.name] = a.value;
    });
    const parent = el.parentElement;
    const nearbyText = parent
      ? (parent.innerText || '').trim().slice(0, 200)
      : '';
    return {
      pageUrl:   location.href,
      pagePath:  location.pathname,
      tag:       (el.tagName || '').toLowerCase(),
      id:        el.id || '',
      classes:   typeof el.className === 'string' ? el.className : '',
      text:      (el.innerText || el.textContent || '').trim().slice(0, 300),
      attributes: {
        ...dataAttrs, ...ariaAttrs,
        role: el.getAttribute('role')  || undefined,
        href: el.getAttribute('href')  || undefined,
        src:  el.getAttribute('src')   || undefined,
      },
      parents:    collectAncestors(el, 4),
      nearbyText,
      rect:      { top: rect.top, left: rect.left, width: rect.width, height: rect.height },
      styles:    getComputedStyleSample(el),
      html:      sanitizeHtml(el, 800),
    };
  }

  function inspectPreview() {
    const viewport = {
      width: window.innerWidth,
      height: window.innerHeight,
      devicePixelRatio: window.devicePixelRatio || 1,
    };
    const problems = [];
    const interactive = Array.from(document.querySelectorAll(
      'a,button,input,select,textarea,[role="button"]'
    )).slice(0, 800);
    const images = Array.from(document.images).slice(0, 500);
    let horizontalOverflow = Math.max(
      document.documentElement.scrollWidth,
      document.body?.scrollWidth || 0
    ) > window.innerWidth + 4;
    if (horizontalOverflow) problems.push('overflow-horizontal');
    const clipped = Array.from(document.querySelectorAll('main,section,article,form,nav,header'))
      .slice(0, 300)
      .filter(el => {
        const rect = el.getBoundingClientRect();
        return rect.width > window.innerWidth + 8 || rect.right > window.innerWidth + 8;
      }).length;
    if (clipped) problems.push(`${clipped}-containers-clipped`);
    const unlabeled = interactive.filter(el => {
      if (el.tagName === 'A' && el.textContent?.trim()) return false;
      if (el.textContent?.trim()) return false;
      return !(el.getAttribute('aria-label') || el.getAttribute('title') ||
        (el.tagName === 'INPUT' && el.getAttribute('type') === 'hidden'));
    }).length;
    if (unlabeled) problems.push(`${unlabeled}-interactive-unlabeled`);
    const brokenImages = images.filter(img => img.complete && img.naturalWidth === 0)
      .map(img => img.currentSrc || img.src).slice(0, 20);
    if (brokenImages.length) problems.push(`${brokenImages.length}-broken-images`);
    return {
      pageUrl: location.href,
      pagePath: location.pathname,
      title: document.title,
      viewport,
      documentSize: {
        width: Math.max(document.documentElement.scrollWidth, document.body?.scrollWidth || 0),
        height: Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight || 0),
      },
      counts: {
        elements: document.querySelectorAll('*').length,
        interactive: interactive.length,
        images: images.length,
        headings: document.querySelectorAll('h1,h2,h3,h4,h5,h6').length,
        forms: document.forms.length,
      },
      problems,
      brokenImages,
      bodyText: (document.body?.innerText || '').trim().slice(0, 3000),
    };
  }

  // ── Modo de seleção ──────────────────────────────────────────────────
  function isOwnElement(el) {
    if (!el) return false;
    const ownIds = ['lunax-visual-highlight-box', 'lunax-visual-cancel-pill', 'vtx-visual-highlight-box', 'vtx-visual-cancel-pill'];
    return ownIds.some(id => el.id === id) || !!el.closest?.('#lunax-visual-highlight-box,#lunax-visual-cancel-pill,#vtx-visual-highlight-box,#vtx-visual-cancel-pill');
  }

  function onPointerMove(e) {
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || isOwnElement(el)) { hideHighlight(); lastHovered = null; return; }
    if (el === lastHovered) return;
    lastHovered = el;
    positionHighlight(el);
  }

  function onClickCapture(e) {
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || isOwnElement(el)) return;
    // Bloqueia a ação real do elemento (link, submit, etc.)
    // APENAS durante o modo de seleção.
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    selectElement(el);
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') {
      exitSelectMode();
      window.parent.postMessage({ type: MSG_CANCEL }, parentOrigin);
    }
  }

  function selectElement(el) {
    const ctx = extractContext(el);
    exitSelectMode();
    // Envia o contexto pra página principal
    window.parent.postMessage({ type: MSG_SELECTED, context: ctx }, parentOrigin);
  }

  function enterSelectMode() {
    if (isSelecting) return;
    isSelecting = true;
    ensureCancelPill().style.display = 'block';
    document.addEventListener('pointermove',  onPointerMove,  true);
    document.addEventListener('click',        onClickCapture, true);
    document.addEventListener('keydown',      onKeyDown,      true);
  }

  function exitSelectMode() {
    isSelecting = false;
    document.removeEventListener('pointermove',  onPointerMove,  true);
    document.removeEventListener('click',        onClickCapture, true);
    document.removeEventListener('keydown',      onKeyDown,      true);
    hideHighlight();
    if (cancelPill) cancelPill.style.display = 'none';
    lastHovered = null;
  }

  // ── Escuta mensagens da página principal ─────────────────────────────
  window.addEventListener('message', (e) => {
    // Valida origem — só aceita comandos de lovable.dev
    if (!ALLOWED_PARENT_ORIGINS.has(e.origin)) return;
    if (e.source !== window.parent) return;
    parentOrigin = e.origin;
    if (!e.data || typeof e.data.type !== 'string') return;
    // START é idempotente — se já estiver selecionando, só confirma que está ativo
    if (e.data.type === MSG_START || e.data.type === 'VTX_FRAME_START_SELECT') {
      exitSelectMode(); // garante estado limpo antes de reentrar
      enterSelectMode();
    }
    if (e.data.type === 'LUNAX_GET_PAGE_CONTEXT') {
      window.parent.postMessage({
        type: 'LUNAX_PAGE_CONTEXT',
        pageUrl: location.href,
        pagePath: location.pathname,
      }, parentOrigin);
    }
    if (e.data.type === MSG_INSPECT) {
      window.parent.postMessage({
        type: MSG_INSPECTED,
        report: inspectPreview(),
        requestId: e.data.requestId || null,
      }, parentOrigin);
    }
    if (e.data.type === MSG_CANCEL || e.data.type === 'VTX_FRAME_CANCEL_SELECT') exitSelectMode();
  });

  // Avisa a página principal que o script está pronto (handshake inicial)
  function sendReady() {
    try {
      window.parent.postMessage({ type: MSG_READY }, parentOrigin);
    } catch { /* cross-origin block, ignore */ }
  }
  sendReady();
  setTimeout(sendReady, 500);
  setTimeout(sendReady, 1500);

})();
