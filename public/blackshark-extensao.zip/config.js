// Configuração pública. Nunca coloque segredos neste arquivo.
window.LUNAX_CONFIG = Object.freeze({
  SUPABASE_URL: "https://htzhueodeeciczhgnyxt.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_NWgF4yv6wGQYMKXuMkTgCA_sZKQ7BYu",
  LICENSE_EDGE_FUNCTION: "license-validate",
  GITHUB_OAUTH_FUNCTION: "github-oauth",
  GITHUB_REPOS_FUNCTION: "github-repos",
  GITHUB_AI_EDIT_FUNCTION: "github-ai-edit",
  GITHUB_APP_FUNCTION: "github-app",
  LUNAX_HANDOFF_FUNCTION: "lunax-handoff",
  LUNAX_AUTH_FUNCTION: "lunax-auth",
  SALES_PANEL_URL: "https://lovable.dev/projects/2447ae9a-9e5a-4d16-baeb-660b0d0ca790",
  SUPPORT_URL: "https://wa.me/55119947664626?text=Ol%C3%A1!%20Preciso%20de%20ajuda%20com%20a%20minha%20chave%20do%20Black%20Shark"
});
window.VERTEX_CONFIG = window.LUNAX_CONFIG;

