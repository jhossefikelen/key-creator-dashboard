function configurePanel(){return chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(error=>console.error('[Black Shark] Falha na janela lateral',error));}
configurePanel();
chrome.runtime.onInstalled.addListener(configurePanel);
chrome.runtime.onStartup.addListener(configurePanel);
